var b=Object.defineProperty;var y=(e,n,t)=>n in e?b(e,n,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[n]=t;var d=(e,n,t)=>y(e,typeof n!="symbol"?n+"":n,t);import{P as u,e as g}from"./sanitize-D3oJtyS4.js";import{N as f,O as x,Q as w,R as c,S as p}from"./main-BS9nt2LU.js";import{a as i}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";import"./i18n-VWbTNjcU.js";class H extends u{constructor(){super({id:"giving",title:i("panels.giving"),showCount:!0,trackActivity:!0,infoTooltip:i("components.giving.infoTooltip")});d(this,"data",null);d(this,"activeTab","platforms");this.showLoading(i("common.loadingGiving"))}setData(t){this.data=t,this.setCount(t.platforms.length),this.renderContent()}renderContent(){if(!this.data)return;const t=this.data,a=f(t.trend),s=x(t.trend),v=`
      <div class="giving-stat-box giving-stat-index">
        <span class="giving-stat-value" style="color: ${w(t.activityIndex)}">${t.activityIndex}</span>
        <span class="giving-stat-label">${i("components.giving.activityIndex")}</span>
      </div>
      <div class="giving-stat-box giving-stat-trend">
        <span class="giving-stat-value" style="color: ${s}">${a} ${g(t.trend)}</span>
        <span class="giving-stat-label">${i("components.giving.trend")}</span>
      </div>
      <div class="giving-stat-box giving-stat-daily">
        <span class="giving-stat-value">${c(t.estimatedDailyFlowUsd)}</span>
        <span class="giving-stat-label">${i("components.giving.estDailyFlow")}</span>
      </div>
      <div class="giving-stat-box giving-stat-crypto">
        <span class="giving-stat-value">${c(t.crypto.dailyInflowUsd)}</span>
        <span class="giving-stat-label">${i("components.giving.cryptoDaily")}</span>
      </div>
    `,m=["platforms","categories","crypto","institutional"],h={platforms:i("components.giving.tabs.platforms"),categories:i("components.giving.tabs.categories"),crypto:i("components.giving.tabs.crypto"),institutional:i("components.giving.tabs.institutional")},$=`
      <div class="giving-tabs">
        ${m.map(o=>`<button class="giving-tab ${this.activeTab===o?"giving-tab-active":""}" data-tab="${o}">${h[o]}</button>`).join("")}
      </div>
    `;let l;switch(this.activeTab){case"platforms":l=this.renderPlatforms(t.platforms);break;case"categories":l=this.renderCategories(t.categories);break;case"crypto":l=this.renderCrypto();break;case"institutional":l=this.renderInstitutional();break}this.content.innerHTML=`
      <div class="giving-panel-content">
        <div class="giving-stats-grid">${v}</div>
        ${$}
        ${l}
      </div>
    `,this.content.querySelectorAll(".giving-tab").forEach(o=>{o.addEventListener("click",()=>{this.activeTab=o.dataset.tab,this.renderContent()})})}renderPlatforms(t){if(t.length===0)return`<div class="panel-empty">${i("common.noDataShort")}</div>`;const a=t.map(s=>{const r=s.dataFreshness==="live"?"giving-fresh-live":s.dataFreshness==="daily"?"giving-fresh-daily":s.dataFreshness==="weekly"?"giving-fresh-weekly":"giving-fresh-annual";return`<tr class="giving-row">
        <td class="giving-platform-name">${g(s.platform)}</td>
        <td class="giving-platform-vol">${c(s.dailyVolumeUsd)}</td>
        <td class="giving-platform-vel">${s.donationVelocity>0?`${s.donationVelocity.toFixed(0)}/hr`:"—"}</td>
        <td class="giving-platform-fresh"><span class="giving-fresh-badge ${r}">${g(s.dataFreshness)}</span></td>
      </tr>`}).join("");return`
      <table class="giving-table">
        <thead>
          <tr>
            <th>${i("components.giving.platform")}</th>
            <th>${i("components.giving.dailyVol")}</th>
            <th>${i("components.giving.velocity")}</th>
            <th>${i("components.giving.freshness")}</th>
          </tr>
        </thead>
        <tbody>${a}</tbody>
      </table>`}renderCategories(t){if(t.length===0)return`<div class="panel-empty">${i("common.noDataShort")}</div>`;const a=t.map(s=>{const r=Math.round(s.share*100),v=s.trending?`<span class="giving-trending-badge">${i("components.giving.trending")}</span>`:"";return`<tr class="giving-row">
        <td class="giving-cat-name">${g(s.category)} ${v}</td>
        <td class="giving-cat-share">
          <div class="giving-share-bar">
            <div class="giving-share-fill" style="width: ${r}%"></div>
          </div>
          <span class="giving-share-label">${p(s.share)}</span>
        </td>
      </tr>`}).join("");return`
      <table class="giving-table giving-cat-table">
        <thead>
          <tr>
            <th>${i("components.giving.category")}</th>
            <th>${i("components.giving.share")}</th>
          </tr>
        </thead>
        <tbody>${a}</tbody>
      </table>`}renderCrypto(){var a;if(!((a=this.data)!=null&&a.crypto))return`<div class="panel-empty">${i("common.noDataShort")}</div>`;const t=this.data.crypto;return`
      <div class="giving-crypto-content">
        <div class="giving-crypto-stats">
          <div class="giving-stat-box">
            <span class="giving-stat-value">${c(t.dailyInflowUsd)}</span>
            <span class="giving-stat-label">${i("components.giving.dailyInflow")}</span>
          </div>
          <div class="giving-stat-box">
            <span class="giving-stat-value">${t.trackedWallets}</span>
            <span class="giving-stat-label">${i("components.giving.wallets")}</span>
          </div>
          <div class="giving-stat-box">
            <span class="giving-stat-value">${p(t.pctOfTotal/100)}</span>
            <span class="giving-stat-label">${i("components.giving.ofTotal")}</span>
          </div>
        </div>
        <div class="giving-crypto-receivers">
          <div class="giving-section-title">${i("components.giving.topReceivers")}</div>
          <ul class="giving-receiver-list">
            ${t.topReceivers.map(s=>`<li>${g(s)}</li>`).join("")}
          </ul>
        </div>
      </div>`}renderInstitutional(){var a;if(!((a=this.data)!=null&&a.institutional))return`<div class="panel-empty">${i("common.noDataShort")}</div>`;const t=this.data.institutional;return`
      <div class="giving-inst-content">
        <div class="giving-inst-grid">
          <div class="giving-stat-box">
            <span class="giving-stat-value">$${t.oecdOdaAnnualUsdBn.toFixed(1)}B</span>
            <span class="giving-stat-label">${i("components.giving.oecdOda")} (${t.oecdDataYear})</span>
          </div>
          <div class="giving-stat-box">
            <span class="giving-stat-value">${t.cafWorldGivingIndex}%</span>
            <span class="giving-stat-label">${i("components.giving.cafIndex")} (${t.cafDataYear})</span>
          </div>
          <div class="giving-stat-box">
            <span class="giving-stat-value">${t.candidGrantsTracked>=1e6?`${(t.candidGrantsTracked/1e6).toFixed(0)}M`:t.candidGrantsTracked.toLocaleString()}</span>
            <span class="giving-stat-label">${i("components.giving.candidGrants")}</span>
          </div>
          <div class="giving-stat-box">
            <span class="giving-stat-value">${g(t.dataLag)}</span>
            <span class="giving-stat-label">${i("components.giving.dataLag")}</span>
          </div>
        </div>
      </div>`}}export{H as GivingPanel};
