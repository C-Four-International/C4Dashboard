var y=Object.defineProperty;var v=(i,s,e)=>s in i?y(i,s,{enumerable:!0,configurable:!0,writable:!0,value:e}):i[s]=e;var p=(i,s,e)=>v(i,typeof s!="symbol"?s+"":s,e);import{P as C,e as d}from"./sanitize-D3oJtyS4.js";import{y as u,z as h}from"./main-BS9nt2LU.js";import{a as o}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";import"./i18n-VWbTNjcU.js";class Z extends C{constructor(){super({id:"climate",title:o("panels.climate"),showCount:!0,trackActivity:!0,infoTooltip:o("components.climate.infoTooltip")});p(this,"anomalies",[]);p(this,"onZoneClick");this.showLoading(o("common.loadingClimateData"))}setZoneClickHandler(e){this.onZoneClick=e}setAnomalies(e){this.anomalies=e,this.setCount(e.length),this.renderContent()}renderContent(){if(this.anomalies.length===0){this.setContent(`<div class="panel-empty">${o("components.climate.noAnomalies")}</div>`);return}const $=[...this.anomalies].sort((t,n)=>{const a={extreme:0,moderate:1,normal:2},l=(a[t.severity]||2)-(a[n.severity]||2);return l!==0?l:Math.abs(n.tempDelta)-Math.abs(t.tempDelta)}).map(t=>{const n=u(t),a=t.tempDelta>0?"climate-warm":"climate-cold",l=t.precipDelta>0?"climate-wet":"climate-dry",m=`severity-${t.severity}`;return`<tr class="climate-row${t.severity==="extreme"?" climate-extreme-row":""}" data-zone="${d(t.zone)}" data-lat="${t.lat}" data-lon="${t.lon}">
        <td class="climate-zone"><span class="climate-icon">${n}</span>${d(t.zone)}</td>
        <td class="climate-num ${a}">${h(t.tempDelta,"°C")}</td>
        <td class="climate-num ${l}">${h(t.precipDelta,"mm")}</td>
        <td><span class="climate-badge ${m}">${o(`components.climate.severity.${t.severity}`)}</span></td>
      </tr>`}).join("");this.setContent(`
      <div class="climate-panel-content">
        <table class="climate-table">
          <thead>
            <tr>
              <th>${o("components.climate.zone")}</th>
              <th>${o("components.climate.temp")}</th>
              <th>${o("components.climate.precip")}</th>
              <th>${o("components.climate.severityLabel")}</th>
            </tr>
          </thead>
          <tbody>${$}</tbody>
        </table>
      </div>
    `),this.content.querySelectorAll(".climate-row").forEach(t=>{t.addEventListener("click",()=>{var c;const n=Number(t.dataset.lat),a=Number(t.dataset.lon),l=t.dataset.zone,m=this.anomalies.find(r=>r.zone===l||r.lat===n&&r.lon===a);Number.isFinite(n)&&Number.isFinite(a)&&((c=this.onZoneClick)==null||c.call(this,n,a,m))})})}}export{Z as ClimateAnomalyPanel};
