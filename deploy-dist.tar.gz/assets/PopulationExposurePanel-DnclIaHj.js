var l=Object.defineProperty;var u=(p,o,e)=>o in p?l(p,o,{enumerable:!0,configurable:!0,writable:!0,value:e}):p[o]=e;var n=(p,o,e)=>u(p,typeof o!="symbol"?o+"":o,e);import{P as d,e as m}from"./sanitize-D3oJtyS4.js";import{A as i}from"./main-BS9nt2LU.js";import{a as s}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";import"./i18n-VWbTNjcU.js";class A extends d{constructor(){super({id:"population-exposure",title:s("panels.populationExposure"),showCount:!0,trackActivity:!0,infoTooltip:s("components.populationExposure.infoTooltip")});n(this,"exposures",[]);this.showLoading(s("common.calculatingExposure"))}setExposures(e){this.exposures=e,this.setCount(e.length),this.renderContent()}renderContent(){if(this.exposures.length===0){this.setContent(`<div class="panel-empty">${s("common.noDataAvailable")}</div>`);return}const e=this.exposures.reduce((t,a)=>t+a.exposedPopulation,0),r=this.exposures.slice(0,30).map(t=>{const a=this.getTypeIcon(t.eventType),c=t.exposedPopulation>=1e6?" popexp-pop-large":"";return`<div class="popexp-card">
        <div class="popexp-card-name">${a} ${m(t.eventName)}</div>
        <div class="popexp-card-meta">
          <span class="popexp-card-pop${c}">${s("components.populationExposure.affectedCount",{count:i(t.exposedPopulation)})}</span>
          <span class="popexp-card-radius">${s("components.populationExposure.radiusKm",{km:String(t.exposureRadiusKm)})}</span>
        </div>
      </div>`}).join("");this.setContent(`
      <div class="popexp-panel-content">
        <div class="popexp-summary">
          <span class="popexp-label">${s("components.populationExposure.totalAffected")}</span>
          <span class="popexp-total">${i(e)}</span>
        </div>
        <div class="popexp-list">${r}</div>
      </div>
    `)}getTypeIcon(e){switch(e){case"state-based":case"non-state":case"one-sided":case"conflict":case"battle":return"⚔️";case"earthquake":return"🌍";case"flood":return"🌊";case"fire":case"wildfire":return"🔥";default:return"📍"}}}export{A as PopulationExposurePanel};
