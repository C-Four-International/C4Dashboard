var g=Object.defineProperty;var m=(l,n,s)=>n in l?g(l,n,{enumerable:!0,configurable:!0,writable:!0,value:s}):l[n]=s;var i=(l,n,s)=>m(l,typeof n!="symbol"?n+"":n,s);import{P as v,e as p}from"./sanitize-D3oJtyS4.js";import{u as f,v as P,w as h}from"./main-BS9nt2LU.js";import{a}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";import"./i18n-VWbTNjcU.js";class N extends v{constructor(){super({id:"strategic-posture",title:a("panels.strategicPosture"),showCount:!1,trackActivity:!0,infoTooltip:a("components.strategicPosture.infoTooltip")});i(this,"postures",[]);i(this,"refreshInterval",null);i(this,"vesselTimeouts",[]);i(this,"loadingElapsedInterval",null);i(this,"loadingStartTime",0);i(this,"onLocationClick");i(this,"lastTimestamp","");i(this,"isStale",!1);this.init()}init(){this.showLoading(),this.fetchAndRender(),this.startAutoRefresh(),this.vesselTimeouts.push(setTimeout(()=>this.reaugmentVessels(),30*1e3)),this.vesselTimeouts.push(setTimeout(()=>this.reaugmentVessels(),60*1e3)),this.vesselTimeouts.push(setTimeout(()=>this.reaugmentVessels(),90*1e3)),this.vesselTimeouts.push(setTimeout(()=>this.reaugmentVessels(),120*1e3))}startAutoRefresh(){this.refreshInterval=setInterval(()=>{this.isPanelVisible()&&this.fetchAndRender()},900*1e3)}isPanelVisible(){return!this.element.classList.contains("hidden")}async reaugmentVessels(){!this.isPanelVisible()||this.postures.length===0||(console.log("[StrategicPosturePanel] Re-augmenting with vessels..."),await this.augmentWithVessels(),this.render())}showLoading(){this.loadingStartTime=Date.now(),this.setContent(`
      <div class="posture-panel">
        <div class="posture-loading">
          <svg class="panel-loading-spinner" width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true">
            <circle cx="18" cy="18" r="14" stroke="rgba(255, 255, 255, 0.2)" stroke-width="3" />
            <path d="M18 4a14 14 0 0 1 14 14" stroke="#ffffff" stroke-width="3" stroke-linecap="round" />
          </svg>
          <div class="posture-loading-title">${a("components.strategicPosture.scanningTheaters")}</div>
          <div class="posture-loading-stages">
            <div class="posture-stage active">
              <span class="posture-stage-dot"></span>
              <span>${a("components.strategicPosture.positions")}</span>
            </div>
            <div class="posture-stage pending">
              <span class="posture-stage-dot"></span>
              <span>${a("components.strategicPosture.navalVesselsLoading")}</span>
            </div>
            <div class="posture-stage pending">
              <span class="posture-stage-dot"></span>
              <span>${a("components.strategicPosture.theaterAnalysis")}</span>
            </div>
          </div>
          <div class="posture-loading-tip">${a("components.strategicPosture.connectingStreams")}</div>
          <div class="posture-loading-elapsed">${a("components.strategicPosture.elapsed",{elapsed:"0"})}</div>
          <div class="posture-loading-note">${a("components.strategicPosture.initialLoadNote")}</div>
        </div>
      </div>
    `),this.startLoadingTimer()}startLoadingTimer(){this.loadingElapsedInterval&&clearInterval(this.loadingElapsedInterval),this.loadingElapsedInterval=setInterval(()=>{const s=Math.floor((Date.now()-this.loadingStartTime)/1e3),e=this.content.querySelector(".posture-loading-elapsed");e&&(e.textContent=a("components.strategicPosture.elapsed",{elapsed:String(s)}))},1e3)}stopLoadingTimer(){this.loadingElapsedInterval&&(clearInterval(this.loadingElapsedInterval),this.loadingElapsedInterval=null)}showLoadingStage(s){const e=this.content.querySelectorAll(".posture-stage");e.length!==0&&e.forEach((r,t)=>{r.classList.remove("active","complete"),s==="aircraft"&&t===0?r.classList.add("active"):s==="vessels"?t===0?r.classList.add("complete"):t===1&&r.classList.add("active"):s==="analysis"&&(t<=1?r.classList.add("complete"):t===2&&r.classList.add("active"))})}async fetchAndRender(){if(this.isPanelVisible())try{this.showLoadingStage("aircraft");const s=await f(this.signal);if(!s||s.postures.length===0){this.showNoData();return}this.postures=s.postures.map(e=>({...e,byOperator:{...e.byOperator}})),this.lastTimestamp=s.timestamp,this.isStale=s.stale||!1,this.showLoadingStage("vessels"),await this.augmentWithVessels(),this.showLoadingStage("analysis"),this.updateBadges(),this.render(),this.isStale&&setTimeout(()=>{this.fetchAndRender()},3e3)}catch(s){if(this.isAbortError(s))return;console.error("[StrategicPosturePanel] Fetch error:",s),this.showFetchError()}}async augmentWithVessels(){try{const{vessels:s}=await P();if(console.log(`[StrategicPosturePanel] Got ${s.length} total military vessels`),s.length===0){this.restoreVesselCounts(),h(this.postures);return}for(const e of this.postures){if(!e.bounds)continue;const r=s.filter(t=>t.lat>=e.bounds.south&&t.lat<=e.bounds.north&&t.lon>=e.bounds.west&&t.lon<=e.bounds.east);e.destroyers=r.filter(t=>t.vesselType==="destroyer").length,e.frigates=r.filter(t=>t.vesselType==="frigate").length,e.carriers=r.filter(t=>t.vesselType==="carrier").length,e.submarines=r.filter(t=>t.vesselType==="submarine").length,e.patrol=r.filter(t=>t.vesselType==="patrol").length,e.auxiliaryVessels=r.filter(t=>t.vesselType==="auxiliary"||t.vesselType==="special"||t.vesselType==="amphibious"||t.vesselType==="icebreaker"||t.vesselType==="research"||t.vesselType==="unknown").length,e.totalVessels=r.length,r.length>0&&console.log(`[StrategicPosturePanel] ${e.shortName}: ${r.length} vessels`,r.map(t=>t.vesselType));for(const t of r){const o=t.operator||"unknown";e.byOperator[o]=(e.byOperator[o]||0)+1}}this.cacheVesselCounts(),h(this.postures),console.log("[StrategicPosturePanel] Augmented with",s.length,"vessels, posture levels recalculated")}catch(s){console.warn("[StrategicPosturePanel] Failed to fetch vessels:",s),this.restoreVesselCounts(),h(this.postures)}}cacheVesselCounts(){try{const s={};for(const e of this.postures)e.totalVessels>0&&(s[e.theaterId]={destroyers:e.destroyers||0,frigates:e.frigates||0,carriers:e.carriers||0,submarines:e.submarines||0,patrol:e.patrol||0,auxiliaryVessels:e.auxiliaryVessels||0,totalVessels:e.totalVessels||0});localStorage.setItem("wm:vesselPosture",JSON.stringify({counts:s,ts:Date.now()}))}catch{}}restoreVesselCounts(){try{const s=localStorage.getItem("wm:vesselPosture");if(!s)return;const{counts:e,ts:r}=JSON.parse(s);if(Date.now()-r>1800*1e3)return;for(const t of this.postures){const o=e[t.theaterId];o&&(t.destroyers=o.destroyers,t.frigates=o.frigates,t.carriers=o.carriers,t.submarines=o.submarines,t.patrol=o.patrol,t.auxiliaryVessels=o.auxiliaryVessels,t.totalVessels=o.totalVessels)}console.log("[StrategicPosturePanel] Restored cached vessel counts")}catch{}}updatePostures(s){if(!s||s.postures.length===0){this.showNoData();return}this.postures=s.postures.map(e=>({...e,byOperator:{...e.byOperator}})),this.lastTimestamp=s.timestamp,this.isStale=s.stale||!1,this.augmentWithVessels().then(()=>{this.updateBadges(),this.render()})}updateBadges(){const s=this.postures.some(r=>r.postureLevel==="critical"),e=this.postures.some(r=>r.postureLevel==="elevated");s?this.setNewBadge(1,!0):e?this.setNewBadge(1,!1):this.clearNewBadge()}refresh(){this.fetchAndRender()}showNoData(){var s;this.stopLoadingTimer(),this.setContent(`
      <div class="posture-panel">
        <div class="posture-no-data">
          <div class="posture-no-data-icon pulse">📡</div>
          <div class="posture-no-data-title">${a("components.strategicPosture.acquiringData")}</div>
          <div class="posture-no-data-desc">
            ${a("components.strategicPosture.acquiringDesc")}
          </div>
          <div class="posture-data-sources">
            <div class="posture-source">
              <span class="posture-source-icon connecting">✈️</span>
              <span>${a("components.strategicPosture.openSkyAdsb")}</span>
            </div>
            <div class="posture-source">
              <span class="posture-source-icon waiting">🚢</span>
              <span>${a("components.strategicPosture.aisVesselStream")}</span>
            </div>
          </div>
          <button class="posture-retry-btn">↻ ${a("components.strategicPosture.retryNow")}</button>
        </div>
      </div>
    `),(s=this.content.querySelector(".posture-retry-btn"))==null||s.addEventListener("click",()=>this.refresh())}showFetchError(){var s;this.stopLoadingTimer(),this.setContent(`
      <div class="posture-panel">
        <div class="posture-no-data">
          <div class="posture-no-data-icon">⚠️</div>
          <div class="posture-no-data-title">${a("components.strategicPosture.feedRateLimited")}</div>
          <div class="posture-no-data-desc">
            ${a("components.strategicPosture.rateLimitedDesc")}
          </div>
          <div class="posture-error-hint">
            <strong>${a("components.strategicPosture.rateLimitedTip")}</strong>
          </div>
          <button class="posture-retry-btn">↻ ${a("components.strategicPosture.tryAgain")}</button>
        </div>
      </div>
    `),(s=this.content.querySelector(".posture-retry-btn"))==null||s.addEventListener("click",()=>this.refresh())}getPostureBadge(s){switch(s){case"critical":return`<span class="posture-badge posture-critical">${a("components.strategicPosture.badges.critical")}</span>`;case"elevated":return`<span class="posture-badge posture-elevated">${a("components.strategicPosture.badges.elevated")}</span>`;default:return`<span class="posture-badge posture-normal">${a("components.strategicPosture.badges.normal")}</span>`}}getTrendIcon(s,e){switch(s){case"increasing":return`<span class="posture-trend trend-up">↗ +${e}%</span>`;case"decreasing":return`<span class="posture-trend trend-down">↘ ${e}%</span>`;default:return`<span class="posture-trend trend-stable">→ ${a("components.strategicPosture.trendStable")}</span>`}}theaterDisplayName(s){const e=`components.strategicPosture.theaters.${s.theaterId}`,r=a(e);return r!==e?r:s.theaterName}renderTheater(s){const e=s.postureLevel!=="normal",r=this.theaterDisplayName(s);if(!e){const d=[];return s.totalAircraft>0&&d.push(`<span class="posture-chip air">✈️ ${s.totalAircraft}</span>`),s.totalVessels>0&&d.push(`<span class="posture-chip naval">⚓ ${s.totalVessels}</span>`),`
        <div class="posture-theater posture-compact" data-lat="${s.centerLat}" data-lon="${s.centerLon}" title="${a("components.strategicPosture.clickToView",{name:p(r)})}">
          <span class="posture-name">${p(s.shortName)}</span>
          <div class="posture-chips">${d.join("")}</div>
          ${this.getPostureBadge(s.postureLevel)}
        </div>
      `}const t=[];s.fighters>0&&t.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.fighters")}">✈️ ${s.fighters}</span>`),s.tankers>0&&t.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.tankers")}">⛽ ${s.tankers}</span>`),s.awacs>0&&t.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.awacs")}">📡 ${s.awacs}</span>`),s.reconnaissance>0&&t.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.recon")}">🔍 ${s.reconnaissance}</span>`),s.transport>0&&t.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.transport")}">📦 ${s.transport}</span>`),s.bombers>0&&t.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.bombers")}">💣 ${s.bombers}</span>`),s.drones>0&&t.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.drones")}">🛸 ${s.drones}</span>`),t.length===0&&s.totalAircraft>0&&t.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.aircraft")}">✈️ ${s.totalAircraft}</span>`);const o=[];s.carriers>0&&o.push(`<span class="posture-stat carrier" title="${a("components.strategicPosture.units.carriers")}">🚢 ${s.carriers}</span>`),s.destroyers>0&&o.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.destroyers")}">⚓ ${s.destroyers}</span>`),s.frigates>0&&o.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.frigates")}">🛥️ ${s.frigates}</span>`),s.submarines>0&&o.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.submarines")}">🦈 ${s.submarines}</span>`),s.patrol>0&&o.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.patrol")}">🚤 ${s.patrol}</span>`),s.auxiliaryVessels>0&&o.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.auxiliary")}">⚓ ${s.auxiliaryVessels}</span>`),o.length===0&&s.totalVessels>0&&o.push(`<span class="posture-stat" title="${a("components.strategicPosture.units.navalVessels")}">⚓ ${s.totalVessels}</span>`);const c=t.length>0,u=o.length>0;return`
      <div class="posture-theater posture-expanded ${s.postureLevel}" data-lat="${s.centerLat}" data-lon="${s.centerLon}" title="${a("components.strategicPosture.clickToViewMap")}">
        <div class="posture-theater-header">
          <span class="posture-name">${p(r)}</span>
          ${this.getPostureBadge(s.postureLevel)}
        </div>

        <div class="posture-forces">
          ${c?`<div class="posture-force-row"><span class="posture-domain">${a("components.strategicPosture.domains.air")}</span><div class="posture-stats">${t.join("")}</div></div>`:""}
          ${u?`<div class="posture-force-row"><span class="posture-domain">${a("components.strategicPosture.domains.sea")}</span><div class="posture-stats">${o.join("")}</div></div>`:""}
        </div>

        <div class="posture-footer">
          ${s.strikeCapable?`<span class="posture-strike">⚡ ${a("components.strategicPosture.strike")}</span>`:""}
          ${this.getTrendIcon(s.trend,s.changePercent)}
          ${s.targetNation?`<span class="posture-focus">→ ${p(s.targetNation)}</span>`:""}
        </div>
      </div>
    `}render(){this.stopLoadingTimer();const s=[...this.postures].sort((o,c)=>{const u={critical:0,elevated:1,normal:2};return(u[o.postureLevel]??2)-(u[c.postureLevel]??2)}),e=this.lastTimestamp?new Date(this.lastTimestamp).toLocaleTimeString():new Date().toLocaleTimeString(),t=`
      <div class="posture-panel">
        ${this.isStale?`<div class="posture-stale-warning">⚠️ ${a("components.strategicPosture.staleWarning")}</div>`:""}
        ${s.map(o=>this.renderTheater(o)).join("")}

        <div class="posture-footer">
          <span class="posture-updated">${this.isStale?"⚠️ ":""}${a("components.strategicPosture.updated")} ${e}</span>
          <button class="posture-refresh-btn" title="${a("components.strategicPosture.refresh")}">↻</button>
        </div>
      </div>
    `;this.setContent(t),this.attachEventListeners()}attachEventListeners(){var e;(e=this.content.querySelector(".posture-refresh-btn"))==null||e.addEventListener("click",()=>{this.refresh()}),this.content.querySelectorAll(".posture-theater").forEach(r=>{r.addEventListener("click",()=>{var c;const t=parseFloat(r.dataset.lat||"0"),o=parseFloat(r.dataset.lon||"0");console.log("[StrategicPosturePanel] Theater clicked:",{lat:t,lon:o,dataLat:r.dataset.lat,dataLon:r.dataset.lon,element:(c=r.textContent)==null?void 0:c.slice(0,30),hasHandler:!!this.onLocationClick}),this.onLocationClick&&!isNaN(t)&&!isNaN(o)?(console.log("[StrategicPosturePanel] Calling onLocationClick with:",t,o),this.onLocationClick(t,o)):console.warn("[StrategicPosturePanel] No handler or invalid coords!",{hasHandler:!!this.onLocationClick,lat:t,lon:o})})})}setLocationClickHandler(s){console.log("[StrategicPosturePanel] setLocationClickHandler called, handler:",typeof s),this.onLocationClick=s,console.log("[StrategicPosturePanel] Handler stored, onLocationClick now:",typeof this.onLocationClick)}getPostures(){return this.postures}show(){const s=this.element.classList.contains("hidden");super.show(),s&&this.fetchAndRender()}destroy(){this.refreshInterval&&clearInterval(this.refreshInterval),this.stopLoadingTimer(),this.vesselTimeouts.forEach(s=>clearTimeout(s)),this.vesselTimeouts=[],super.destroy()}}export{N as StrategicPosturePanel};
