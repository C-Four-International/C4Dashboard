var m=Object.defineProperty;var $=(o,i,t)=>i in o?m(o,i,{enumerable:!0,configurable:!0,writable:!0,value:t}):o[i]=t;var n=(o,i,t)=>$(o,typeof i!="symbol"?i+"":i,t);import{P as y,i as w,e}from"./sanitize-D3oJtyS4.js";import{a as s,j as D}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";class F extends y{constructor(){super({id:"trade-policy",title:s("panels.tradePolicy")});n(this,"restrictionsData",null);n(this,"tariffsData",null);n(this,"flowsData",null);n(this,"barriersData",null);n(this,"activeTab","restrictions");this.content.addEventListener("click",t=>{const a=t.target.closest(".economic-tab");if(!a)return;const r=a.dataset.tab;r&&r!==this.activeTab&&(this.activeTab=r,this.render())})}updateRestrictions(t){this.restrictionsData=t,this.render()}updateTariffs(t){this.tariffsData=t,this.render()}updateFlows(t){this.flowsData=t,this.render()}updateBarriers(t){this.barriersData=t,this.render()}render(){var h,f,v,b;if(D()&&!w("wtoTrade")){this.setContent(`<div class="economic-empty">${s("components.tradePolicy.apiKeyMissing")}</div>`);return}const t=this.tariffsData&&this.tariffsData.datapoints.length>0,a=this.flowsData&&this.flowsData.flows.length>0,r=this.barriersData&&this.barriersData.barriers.length>0,c=`
      <div class="economic-tabs">
        <button class="economic-tab ${this.activeTab==="restrictions"?"active":""}" data-tab="restrictions">
          ${s("components.tradePolicy.restrictions")}
        </button>
        ${t?`<button class="economic-tab ${this.activeTab==="tariffs"?"active":""}" data-tab="tariffs">
          ${s("components.tradePolicy.tariffs")}
        </button>`:""}
        ${a?`<button class="economic-tab ${this.activeTab==="flows"?"active":""}" data-tab="flows">
          ${s("components.tradePolicy.flows")}
        </button>`:""}
        ${r?`<button class="economic-tab ${this.activeTab==="barriers"?"active":""}" data-tab="barriers">
          ${s("components.tradePolicy.barriers")}
        </button>`:""}
      </div>
    `,l=this.activeTab==="restrictions"?(((h=this.restrictionsData)==null?void 0:h.restrictions.length)??0)>0:this.activeTab==="tariffs"?(((f=this.tariffsData)==null?void 0:f.datapoints.length)??0)>0:this.activeTab==="flows"?(((v=this.flowsData)==null?void 0:v.flows.length)??0)>0:(((b=this.barriersData)==null?void 0:b.barriers.length)??0)>0,p=this.activeTab==="restrictions"?this.restrictionsData:this.activeTab==="tariffs"?this.tariffsData:this.activeTab==="flows"?this.flowsData:this.barriersData,u=!l&&(p!=null&&p.upstreamUnavailable)?`<div class="economic-warning">${s("components.tradePolicy.upstreamUnavailable")}</div>`:"";let d="";switch(this.activeTab){case"restrictions":d=this.renderRestrictions();break;case"tariffs":d=this.renderTariffs();break;case"flows":d=this.renderFlows();break;case"barriers":d=this.renderBarriers();break}this.setContent(`
      ${c}
      ${u}
      <div class="economic-content">${d}</div>
      <div class="economic-footer">
        <span class="economic-source">WTO</span>
      </div>
    `)}renderRestrictions(){return!this.restrictionsData||this.restrictionsData.restrictions.length===0?`<div class="economic-empty">${s("components.tradePolicy.noRestrictions")}</div>`:`<div class="trade-restrictions-list">
      ${this.restrictionsData.restrictions.map(t=>{const a=t.status==="high"?"status-active":t.status==="moderate"?"status-notified":"status-terminated",r=t.status==="high"?s("components.tradePolicy.highTariff"):t.status==="moderate"?s("components.tradePolicy.moderateTariff"):s("components.tradePolicy.lowTariff"),c=this.renderSourceUrl(t.sourceUrl);return`<div class="trade-restriction-card">
          <div class="trade-restriction-header">
            <span class="trade-country">${e(t.reportingCountry)}</span>
            <span class="trade-badge">${e(t.measureType)}</span>
            <span class="trade-status ${a}">${r}</span>
          </div>
          <div class="trade-restriction-body">
            <div class="trade-sector">${e(t.productSector)}</div>
            ${t.description?`<div class="trade-description">${e(t.description)}</div>`:""}
            ${t.affectedCountry?`<div class="trade-affected">Affects: ${e(t.affectedCountry)}</div>`:""}
          </div>
          <div class="trade-restriction-footer">
            ${t.notifiedAt?`<span class="trade-date">${e(t.notifiedAt)}</span>`:""}
            ${c}
          </div>
        </div>`}).join("")}
    </div>`}renderTariffs(){if(!this.tariffsData||this.tariffsData.datapoints.length===0)return`<div class="economic-empty">${s("components.tradePolicy.noTariffData")}</div>`;const t=[...this.tariffsData.datapoints].sort((a,r)=>r.year-a.year).map(a=>`<tr>
        <td>${a.year}</td>
        <td>${a.tariffRate.toFixed(1)}%</td>
        <td>${e(a.productSector||"—")}</td>
      </tr>`).join("");return`<div class="trade-tariffs-table">
      <table>
        <thead>
          <tr>
            <th>Year</th>
            <th>${s("components.tradePolicy.appliedRate")}</th>
            <th>Sector</th>
          </tr>
        </thead>
        <tbody>${t}</tbody>
      </table>
    </div>`}renderFlows(){return!this.flowsData||this.flowsData.flows.length===0?`<div class="economic-empty">${s("components.tradePolicy.noFlowData")}</div>`:`<div class="trade-flows-list">
      ${this.flowsData.flows.map(t=>{const a=t.yoyExportChange>=0?"▲":"▼",r=t.yoyImportChange>=0?"▲":"▼",c=t.yoyExportChange>=0?"change-positive":"change-negative",l=t.yoyImportChange>=0?"change-positive":"change-negative";return`<div class="trade-flow-card">
          <div class="trade-flow-year">${t.year}</div>
          <div class="trade-flow-metrics">
            <div class="trade-flow-metric">
              <span class="trade-flow-label">${s("components.tradePolicy.exports")}</span>
              <span class="trade-flow-value">$${t.exportValueUsd.toFixed(0)}M</span>
              <span class="trade-flow-change ${c}">${a} ${Math.abs(t.yoyExportChange).toFixed(1)}%</span>
            </div>
            <div class="trade-flow-metric">
              <span class="trade-flow-label">${s("components.tradePolicy.imports")}</span>
              <span class="trade-flow-value">$${t.importValueUsd.toFixed(0)}M</span>
              <span class="trade-flow-change ${l}">${r} ${Math.abs(t.yoyImportChange).toFixed(1)}%</span>
            </div>
          </div>
        </div>`}).join("")}
    </div>`}renderBarriers(){return!this.barriersData||this.barriersData.barriers.length===0?`<div class="economic-empty">${s("components.tradePolicy.noBarriers")}</div>`:`<div class="trade-barriers-list">
      ${this.barriersData.barriers.map(t=>{const a=this.renderSourceUrl(t.sourceUrl);return`<div class="trade-barrier-card">
          <div class="trade-barrier-header">
            <span class="trade-country">${e(t.notifyingCountry)}</span>
            <span class="trade-badge">${e(t.measureType)}</span>
          </div>
          <div class="trade-barrier-body">
            <div class="trade-barrier-title">${e(t.title)}</div>
            ${t.productDescription?`<div class="trade-sector">${e(t.productDescription)}</div>`:""}
            ${t.objective?`<div class="trade-description">${e(t.objective)}</div>`:""}
          </div>
          <div class="trade-barrier-footer">
            ${t.dateDistributed?`<span class="trade-date">${e(t.dateDistributed)}</span>`:""}
            ${a}
          </div>
        </div>`}).join("")}
    </div>`}renderSourceUrl(t){if(!t)return"";try{const a=new URL(t);if(a.protocol==="http:"||a.protocol==="https:")return`<a href="${e(t)}" target="_blank" rel="noopener" class="trade-source-link">Source</a>`}catch{}return""}}export{F as TradePolicyPanel};
