import{P as d,s as a,e as c}from"./sanitize-D3oJtyS4.js";import{a as i}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";class h extends d{constructor(){super({id:"polymarket",title:i("panels.polymarket"),infoTooltip:i("components.prediction.infoTooltip")})}formatVolume(t){return t?t>=1e6?`$${(t/1e6).toFixed(1)}M`:t>=1e3?`$${(t/1e3).toFixed(0)}K`:`$${t.toFixed(0)}`:""}renderPredictions(t){if(t.length===0){this.showError(i("common.failedPredictions"));return}const l=t.map(e=>{const o=Math.round(e.yesPrice),n=100-o,s=this.formatVolume(e.volume),r=a(e.url||"");return`
      <div class="prediction-item">
        ${r?`<a href="${r}" target="_blank" rel="noopener" class="prediction-question prediction-link">${c(e.title)}</a>`:`<div class="prediction-question">${c(e.title)}</div>`}
        ${s?`<div class="prediction-volume">${i("components.predictions.vol")}: ${s}</div>`:""}
        <div class="prediction-bar">
          <div class="prediction-yes" style="width: ${o}%">
            <span class="prediction-label">${i("components.predictions.yes")} ${o}%</span>
          </div>
          <div class="prediction-no" style="width: ${n}%">
            <span class="prediction-label">${i("components.predictions.no")} ${n}%</span>
          </div>
        </div>
      </div>
    `}).join("");this.setContent(l)}}export{h as PredictionPanel};
