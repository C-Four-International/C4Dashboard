var f=Object.defineProperty;var y=(o,i,a)=>i in o?f(o,i,{enumerable:!0,configurable:!0,writable:!0,value:a}):o[i]=a;var r=(o,i,a)=>y(o,typeof i!="symbol"?i+"":i,a);import{P as T,e as C}from"./sanitize-D3oJtyS4.js";import{x as c}from"./main-BS9nt2LU.js";import{a as s}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";import"./i18n-VWbTNjcU.js";class j extends T{constructor(){super({id:"displacement",title:s("panels.displacement"),showCount:!0,trackActivity:!0,infoTooltip:s("components.displacement.infoTooltip")});r(this,"data",null);r(this,"activeTab","origins");r(this,"onCountryClick");this.showLoading(s("common.loadingDisplacement"))}setCountryClickHandler(a){this.onCountryClick=a}setData(a){this.data=a,this.setCount(a.countries.length),this.renderContent()}renderContent(){if(!this.data)return;const a=this.data.globalTotals,b=[{label:s("components.displacement.refugees"),value:c(a.refugees),cls:"disp-stat-refugees"},{label:s("components.displacement.asylumSeekers"),value:c(a.asylumSeekers),cls:"disp-stat-asylum"},{label:s("components.displacement.idps"),value:c(a.idps),cls:"disp-stat-idps"},{label:s("components.displacement.total"),value:c(a.total),cls:"disp-stat-total"}].map(t=>`<div class="disp-stat-box ${t.cls}">
        <span class="disp-stat-value">${t.value}</span>
        <span class="disp-stat-label">${t.label}</span>
      </div>`).join(""),g=`
      <div class="disp-tabs">
        <button class="disp-tab ${this.activeTab==="origins"?"disp-tab-active":""}" data-tab="origins">${s("components.displacement.origins")}</button>
        <button class="disp-tab ${this.activeTab==="hosts"?"disp-tab-active":""}" data-tab="hosts">${s("components.displacement.hosts")}</button>
      </div>
    `;let p;this.activeTab==="origins"?p=[...this.data.countries].filter(t=>t.refugees+t.asylumSeekers>0).sort((t,e)=>e.refugees+e.asylumSeekers-(t.refugees+t.asylumSeekers)):p=[...this.data.countries].filter(t=>(t.hostTotal||0)>0).sort((t,e)=>(e.hostTotal||0)-(t.hostTotal||0));const u=p.slice(0,30);let m;if(u.length===0)m=`<div class="panel-empty">${s("common.noDataShort")}</div>`;else{const t=u.map(e=>{const l=e.hostTotal||0,d=this.activeTab==="origins"?e.refugees+e.asylumSeekers:l,n=this.activeTab==="origins"?e.totalDisplaced:l,v=n>=1e6?"disp-crisis":n>=5e5?"disp-high":n>=1e5?"disp-elevated":"",h=n>=1e6?s("components.displacement.badges.crisis"):n>=5e5?s("components.displacement.badges.high"):n>=1e5?s("components.displacement.badges.elevated"):"",$=h?`<span class="disp-badge ${v}">${h}</span>`:"";return`<tr class="disp-row" data-lat="${e.lat||""}" data-lon="${e.lon||""}">
          <td class="disp-name">${C(e.name)}</td>
          <td class="disp-status">${$}</td>
          <td class="disp-count">${c(d)}</td>
        </tr>`}).join("");m=`
        <table class="disp-table">
          <thead>
            <tr>
              <th>${s("components.displacement.country")}</th>
              <th>${s("components.displacement.status")}</th>
              <th>${s("components.displacement.count")}</th>
            </tr>
          </thead>
          <tbody>${t}</tbody>
        </table>`}this.content.innerHTML=`
      <div class="disp-panel-content">
        <div class="disp-stats-grid">${b}</div>
        ${g}
        ${m}
      </div>
    `,this.content.querySelectorAll(".disp-tab").forEach(t=>{t.addEventListener("click",()=>{this.activeTab=t.dataset.tab,this.renderContent()})}),this.content.querySelectorAll(".disp-row").forEach(t=>{t.addEventListener("click",()=>{var d;const e=Number(t.dataset.lat),l=Number(t.dataset.lon);Number.isFinite(e)&&Number.isFinite(l)&&((d=this.onCountryClick)==null||d.call(this,e,l))})})}}export{j as DisplacementPanel};
