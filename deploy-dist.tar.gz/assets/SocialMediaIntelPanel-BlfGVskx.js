var m=Object.defineProperty;var y=(f,h,e)=>h in f?m(f,h,{enumerable:!0,configurable:!0,writable:!0,value:e}):f[h]=e;var p=(f,h,e)=>y(f,typeof h!="symbol"?h+"":h,e);import{P as b,r as S,$,e as c,s as x}from"./sanitize-D3oJtyS4.js";import{a as g}from"./pipelines-data-BE8dV597.js";import{k as w}from"./main-BS9nt2LU.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";class Q extends b{constructor(){super({id:"social-intel",title:g("panels.socialIntel")||"Social Media Intel",showCount:!0,trackActivity:!0,infoTooltip:g("components.socialIntel.infoTooltip")||"Live OSINT and breaking news monitor for Bluesky and Telegram. Cleans noise locally, clusters correlated events with Google AI Studio text-embedding-004, cross-references multi-source reporting, and generates air-gapped factual briefings under 25 words (cached for 3 hours)."});p(this,"briefings",[]);p(this,"filter","all");p(this,"searchQuery","");p(this,"expandedBriefings",new Set);p(this,"isRefreshing",!1);p(this,"responseMeta",null);this.init()}async init(){await this.loadData()}async refresh(){await this.loadData(!0)}showLoading(e=g("components.socialIntel.loading")||"Correlating OSINT and breaking news..."){S(this.content,$(`
        <div class="social-intel-loading-container">
          <div class="social-intel-spinner-badge">
            <svg class="social-intel-spinner-wheel" width="30" height="30" viewBox="0 0 36 36" fill="none" aria-hidden="true">
              <circle cx="18" cy="18" r="14" stroke="rgba(0, 0, 0, 0.15)" stroke-width="3" />
              <path d="M18 4a14 14 0 0 1 14 14" stroke="#000000" stroke-width="3" stroke-linecap="round" />
            </svg>
          </div>
          <div class="social-intel-loading-text">${c(e)}</div>
        </div>
      `))}async loadData(e=!1){if(this.isRefreshing)return;this.isRefreshing=!0;const t=this.content.querySelector("#social-intel-refresh-btn");t&&t.classList.add("loading"),this.briefings.length===0?this.showLoading():this.setDataBadge("cached");try{const s=await w(e);this.responseMeta=s,this.briefings=s.briefings||[],this.setCount(this.briefings.length);const r=e?"live":"cached";this.setDataBadge(r),this.render()}catch(s){console.error("[SocialMediaIntelPanel] Load error:",s),this.briefings.length===0?this.showError(g("common.failedToLoad")||"Failed to load social media intelligence briefings."):this.setDataBadge("unavailable")}finally{this.isRefreshing=!1;const s=this.content.querySelector("#social-intel-refresh-btn");s&&s.classList.remove("loading")}}getFilteredBriefings(){const e=this.searchQuery.trim().toLowerCase();return this.briefings.filter(t=>{if(this.filter==="multisource"&&!t.isMultiSource||this.filter==="bluesky"&&!t.platforms.includes("bluesky")||this.filter==="telegram"&&!t.platforms.includes("telegram"))return!1;if(e){const s=t.briefing.toLowerCase().includes(e),r=t.sources.some(a=>a.author.toLowerCase().includes(e)||a.cleanedText.toLowerCase().includes(e)||a.translatedText&&a.translatedText.toLowerCase().includes(e));if(!s&&!r)return!1}return!0})}render(){if(!this.content.querySelector(".social-intel-panel-inner")){this.renderFull();return}this.updateToolbar(),this.updateCardsList(),this.updateFooter()}renderFull(){var n,d,l,v;const e=this.briefings.filter(u=>u.platforms.includes("bluesky")).length,t=this.briefings.filter(u=>u.platforms.includes("telegram")).length,s=this.briefings.filter(u=>u.isMultiSource).length,r=`
      <div class="social-intel-toolbar" id="social-intel-toolbar">
        <div class="social-intel-filter-chips">
          <button class="social-chip ${this.filter==="all"?"active":""}" data-filter="all">
            All (${this.briefings.length})
          </button>
          <button class="social-chip ${this.filter==="multisource"?"active":""}" data-filter="multisource" title="Events corroborated by >= 2 independent sources">
            ⚡ Corroborated (${s})
          </button>
          <button class="social-chip ${this.filter==="bluesky"?"active":""}" data-filter="bluesky">
            🦋 Bluesky (${e})
          </button>
          <button class="social-chip ${this.filter==="telegram"?"active":""}" data-filter="telegram">
            ✈️ Telegram (${t})
          </button>
        </div>
        <div class="social-intel-controls">
          <div class="social-intel-search-wrapper">
            <input
              type="text"
              class="social-intel-search-input"
              id="social-intel-search-input"
              placeholder="Search intel..."
              value="${c(this.searchQuery)}"
            />
            <button
              class="social-search-clear"
              id="social-search-clear"
              style="display: ${this.searchQuery?"":"none"};"
              title="Clear search"
              aria-label="Clear search"
            >×</button>
          </div>
          <button
            class="social-intel-refresh-btn ${this.isRefreshing?"loading":""}"
            id="social-intel-refresh-btn"
            title="Refresh intel feed (3h cache)"
            aria-label="Refresh intel feed"
          ><span class="social-refresh-icon"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#000000" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8" /><path d="M21 3v5h-5" /></svg></span><svg class="social-loading-wheel" width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="9" stroke="rgba(0, 0, 0, 0.18)" stroke-width="2.5" /><path d="M12 3a9 9 0 0 1 9 9" stroke="#000000" stroke-width="2.5" stroke-linecap="round" /></svg></button>
        </div>
      </div>
    `,a=this.getFilteredBriefings(),i=`
      <div class="social-intel-cards-list" id="social-intel-cards-list">
        ${a.length===0?this.renderEmptyState():a.map(u=>this.renderBriefingCard(u)).join("")}
      </div>
    `,o=this.responseMeta?`
      <div class="social-intel-footer" id="social-intel-footer">
        <span class="social-footer-stat">Model: ${c(this.responseMeta.modelUsed||"AI Studio Low-Cost")}</span>
        <span class="social-footer-stat">Monitored: ${((d=(n=this.responseMeta.sourcesMonitored)==null?void 0:n.bluesky)==null?void 0:d.length)||10} Bluesky · ${((v=(l=this.responseMeta.sourcesMonitored)==null?void 0:l.telegram)==null?void 0:v.length)||8} Telegram</span>
      </div>
    `:"";this.content.innerHTML=`
      <div class="social-intel-panel-inner">
        ${r}
        ${i}
        ${o}
      </div>
    `,this.attachEventListeners()}renderEmptyState(){const e=!!this.searchQuery.trim();return`
      <div class="social-intel-empty-state">
        <div class="social-empty-icon">📡</div>
        <div class="social-empty-title">${e?"No matching briefings":"Monitoring OSINT Channels"}</div>
        <div class="social-empty-sub">
          ${e?"Try clearing your search query or switching filters.":"Scraping prominent Bluesky and Telegram OSINT feeds for corroborated breaking events."}
        </div>
      </div>
    `}updateToolbar(){const e=this.briefings.filter(l=>l.platforms.includes("bluesky")).length,t=this.briefings.filter(l=>l.platforms.includes("telegram")).length,s=this.briefings.filter(l=>l.isMultiSource).length,r=this.content.querySelector('.social-chip[data-filter="all"]');r&&(r.textContent=`All (${this.briefings.length})`);const a=this.content.querySelector('.social-chip[data-filter="multisource"]');a&&(a.textContent=`⚡ Corroborated (${s})`);const i=this.content.querySelector('.social-chip[data-filter="bluesky"]');i&&(i.textContent=`🦋 Bluesky (${e})`);const o=this.content.querySelector('.social-chip[data-filter="telegram"]');o&&(o.textContent=`✈️ Telegram (${t})`),this.content.querySelectorAll(".social-chip").forEach(l=>{l.classList.toggle("active",l.dataset.filter===this.filter)});const n=this.content.querySelector("#social-intel-search-input");n&&document.activeElement!==n&&n.value!==this.searchQuery&&(n.value=this.searchQuery);const d=this.content.querySelector("#social-search-clear");d&&(d.style.display=this.searchQuery?"":"none")}updateCardsList(){const e=this.content.querySelector("#social-intel-cards-list");if(!e){this.render();return}const t=this.getFilteredBriefings();t.length===0?e.innerHTML=this.renderEmptyState():e.innerHTML=t.map(s=>this.renderBriefingCard(s)).join("")}updateFooter(){var s,r,a,i;const e=this.content.querySelector("#social-intel-footer");if(!this.responseMeta){e==null||e.remove();return}const t=`
      <span class="social-footer-stat">Model: ${c(this.responseMeta.modelUsed||"AI Studio Low-Cost")}</span>
      <span class="social-footer-stat">Monitored: ${((r=(s=this.responseMeta.sourcesMonitored)==null?void 0:s.bluesky)==null?void 0:r.length)||10} Bluesky · ${((i=(a=this.responseMeta.sourcesMonitored)==null?void 0:a.telegram)==null?void 0:i.length)||8} Telegram</span>
    `;if(e)e.innerHTML=t;else{const o=this.content.querySelector(".social-intel-panel-inner");if(o){const n=document.createElement("div");n.className="social-intel-footer",n.id="social-intel-footer",n.innerHTML=t,o.appendChild(n)}}}renderBriefingCard(e){const t=this.expandedBriefings.has(e.id),s=e.platforms.map(a=>a==="bluesky"?"🦋":"✈️").join(" "),r=e.isMultiSource?`<span class="social-corroboration-badge verified" title="Corroborated by ${e.corroborationScore} independent sources">✓ ${e.corroborationScore} Sources Verified</span>`:'<span class="social-corroboration-badge single" title="Single monitored source reporting">Single Monitor Signal</span>';return`
      <article class="social-intel-card ${e.isMultiSource?"card-corroborated":""}" data-id="${c(e.id)}">
        <div class="social-intel-card-header">
          <div class="social-card-meta-left">
            <span class="social-freshness-dot"></span>
            <span class="social-freshness-text" title="Generated ${c(e.createdAt)}">${c(e.freshness)}</span>
            <span class="social-wordcount-chip">${e.wordCount} words</span>
          </div>
          <div class="social-card-meta-right">
            ${r}
            <span class="social-platform-icons">${s}</span>
          </div>
        </div>

        <div class="social-briefing-text">
          ${c(e.briefing)}
        </div>

        <div class="social-card-actions">
          <button
            type="button"
            class="social-expand-sources-btn ${t?"expanded":""}"
            data-action="toggle-expand"
            data-id="${c(e.id)}"
            aria-expanded="${t?"true":"false"}"
          >
            <span>${e.sources.length} ${e.sources.length===1?"Source":"Sources"}</span>
            <span class="social-chevron">${t?"▲":"▼"}</span>
          </button>
        </div>

        ${t?this.renderSourcesDrawer(e.sources):""}
      </article>
    `}renderSourcesDrawer(e){return`
      <div class="social-sources-drawer">
        <div class="social-sources-title">CORROBORATING SOURCES & LINKS</div>
        <div class="social-sources-list">
          ${e.map(t=>{const s=t.platform==="bluesky"?"🦋 Bluesky":"✈️ Telegram",r=t.cleanedText.length>220?`${t.cleanedText.slice(0,220)}...`:t.cleanedText,a=!!(t.isTranslated&&t.translatedText&&t.translatedText!==t.cleanedText),i=a&&t.translatedText?t.translatedText.length>240?`${t.translatedText.slice(0,240)}...`:t.translatedText:"";return`
                <div class="social-source-item" data-platform="${t.platform}">
                  <div class="social-source-header">
                    <div class="social-source-author-wrap">
                      <span class="social-source-platform-tag ${t.platform}">${s}</span>
                      <span class="social-source-author">${c(t.author)}</span>
                    </div>
                    <div class="social-source-right">
                      <span class="social-source-freshness">${c(t.freshness)}</span>
                      <a
                        href="${x(t.url)}"
                        target="_blank"
                        rel="noopener noreferrer"
                        class="social-source-link"
                        title="Open original post on ${t.platform}"
                        data-action="view-source"
                      >
                        Open Post ↗
                      </a>
                    </div>
                  </div>
                  <div class="social-source-snippet">
                    ${a?`
                          <div class="social-source-translation-meta">
                            <span class="social-source-translation-badge" title="Translated using Google pre-trained translation API">
                              🌐 Translated to English
                            </span>
                          </div>
                          <div class="social-source-translated-text">
                            "${c(i)}"
                          </div>
                          <details class="social-source-orig-details">
                            <summary class="social-source-orig-summary">Original post snippet</summary>
                            <div class="social-source-orig-text">"${c(r)}"</div>
                          </details>
                        `:`"${c(r)}"`}
                  </div>
                </div>
              `}).join("")}
        </div>
      </div>
    `}attachEventListeners(){const e=this.content.querySelector("#social-intel-toolbar");e==null||e.querySelectorAll(".social-chip").forEach(i=>{i.addEventListener("click",o=>{o.stopPropagation();const n=i.dataset.filter;n&&n!==this.filter&&(this.filter=n,e.querySelectorAll(".social-chip").forEach(d=>{d.classList.toggle("active",d.dataset.filter===this.filter)}),this.updateCardsList())})});const t=this.content.querySelector("#social-intel-search-input"),s=this.content.querySelector("#social-search-clear");t==null||t.addEventListener("input",i=>{this.searchQuery=i.target.value,s&&(s.style.display=this.searchQuery?"":"none"),this.updateCardsList()}),t==null||t.addEventListener("keydown",i=>{i.key==="Escape"&&this.searchQuery&&(i.stopPropagation(),this.searchQuery="",t&&(t.value=""),s&&(s.style.display="none"),this.updateCardsList())}),s==null||s.addEventListener("click",i=>{i.stopPropagation(),this.searchQuery="",t&&(t.value="",t.focus()),s&&(s.style.display="none"),this.updateCardsList()});const r=this.content.querySelector("#social-intel-refresh-btn");r==null||r.addEventListener("click",i=>{i.stopPropagation(),this.loadData(!0)});const a=this.content.querySelector("#social-intel-cards-list");a==null||a.addEventListener("click",i=>{const o=i.target.closest('[data-action="toggle-expand"]');if(o){i.preventDefault(),i.stopPropagation();const n=o.dataset.id;n&&this.toggleExpand(n,o)}})}toggleExpand(e,t){const s=this.expandedBriefings.has(e);s?this.expandedBriefings.delete(e):this.expandedBriefings.add(e);const r=t?t.closest(".social-intel-card"):this.content.querySelector(`.social-intel-card[data-id="${e}"]`);if(r){const a=t||r.querySelector('[data-action="toggle-expand"]'),i=!s;if(a){a.classList.toggle("expanded",i),a.setAttribute("aria-expanded",i?"true":"false");const n=a.querySelector(".social-chevron");n&&(n.textContent=i?"▲":"▼")}const o=r.querySelector(".social-sources-drawer");if(i)if(o)o.style.display="";else{const n=this.briefings.find(d=>d.id===e);if(n){const d=document.createElement("div");d.innerHTML=this.renderSourcesDrawer(n.sources);const l=d.firstElementChild;l&&r.appendChild(l)}}else o&&o.remove();return}this.render()}}export{Q as SocialMediaIntelPanel};
