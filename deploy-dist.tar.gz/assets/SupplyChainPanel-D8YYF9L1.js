var $=Object.defineProperty;var g=(c,o,t)=>o in c?$(c,o,{enumerable:!0,configurable:!0,writable:!0,value:t}):c[o]=t;var d=(c,o,t)=>g(c,typeof o!="symbol"?o+"":o,t);import{P as b,e,i as k}from"./sanitize-D3oJtyS4.js";import{a as i,j as y}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";class P extends b{constructor(){super({id:"supply-chain",title:i("panels.supplyChain")});d(this,"shippingData",null);d(this,"chokepointData",null);d(this,"mineralsData",null);d(this,"activeTab","chokepoints");this.content.addEventListener("click",t=>{const s=t.target.closest(".economic-tab");if(!s)return;const a=s.dataset.tab;a&&a!==this.activeTab&&(this.activeTab=a,this.render())})}updateShippingRates(t){this.shippingData=t,this.render()}updateChokepointStatus(t){this.chokepointData=t,this.render()}updateCriticalMinerals(t){this.mineralsData=t,this.render()}render(){const t=`
      <div class="economic-tabs">
        <button class="economic-tab ${this.activeTab==="chokepoints"?"active":""}" data-tab="chokepoints">
          ${i("components.supplyChain.chokepoints")}
        </button>
        <button class="economic-tab ${this.activeTab==="shipping"?"active":""}" data-tab="shipping">
          ${i("components.supplyChain.shipping")}
        </button>
        <button class="economic-tab ${this.activeTab==="minerals"?"active":""}" data-tab="minerals">
          ${i("components.supplyChain.minerals")}
        </button>
      </div>
    `,s=this.activeTab==="chokepoints"?this.chokepointData:this.activeTab==="shipping"?this.shippingData:this.mineralsData,a=s!=null&&s.upstreamUnavailable?`<div class="economic-warning">${i("components.supplyChain.upstreamUnavailable")}</div>`:"";let n="";switch(this.activeTab){case"chokepoints":n=this.renderChokepoints();break;case"shipping":n=this.renderShipping();break;case"minerals":n=this.renderMinerals();break}this.setContent(`
      ${t}
      ${a}
      <div class="economic-content">${n}</div>
      <div class="economic-footer">
        <span class="economic-source">${i("components.supplyChain.sources")}</span>
      </div>
    `)}renderChokepoints(){return!this.chokepointData||this.chokepointData.chokepoints.length===0?`<div class="economic-empty">${i("components.supplyChain.noChokepoints")}</div>`:`<div class="trade-restrictions-list">
      ${[...this.chokepointData.chokepoints].sort((t,s)=>s.disruptionScore-t.disruptionScore).map(t=>{const s=t.status==="red"?"status-active":t.status==="yellow"?"status-notified":"status-terminated",a=t.status==="red"?"sc-dot-red":t.status==="yellow"?"sc-dot-yellow":"sc-dot-green";return`<div class="trade-restriction-card">
          <div class="trade-restriction-header">
            <span class="trade-country">${e(t.name)}</span>
            <span class="sc-status-dot ${a}"></span>
            <span class="trade-badge">${t.disruptionScore}/100</span>
            <span class="trade-status ${s}">${e(t.status)}</span>
          </div>
          <div class="trade-restriction-body">
            <div class="trade-sector">${t.activeWarnings} ${i("components.supplyChain.warnings")}</div>
            <div class="trade-description">${e(t.description)}</div>
            <div class="trade-affected">${e(t.affectedRoutes.join(", "))}</div>
          </div>
        </div>`}).join("")}
    </div>`}renderShipping(){return y()&&!k("supplyChain")?`<div class="economic-empty">${i("components.supplyChain.fredKeyMissing")}</div>`:!this.shippingData||this.shippingData.indices.length===0?`<div class="economic-empty">${i("components.supplyChain.noShipping")}</div>`:`<div class="trade-restrictions-list">
      ${this.shippingData.indices.map(t=>{const s=t.changePct>=0?"change-positive":"change-negative",a=t.changePct>=0?"▲":"▼",n=this.renderSparkline(t.history.map(p=>p.value));return`<div class="trade-restriction-card">
          ${t.spikeAlert?`<div class="economic-warning">${i("components.supplyChain.spikeAlert")}</div>`:""}
          <div class="trade-restriction-header">
            <span class="trade-country">${e(t.name)}</span>
            <span class="trade-badge">${t.currentValue.toFixed(0)} ${e(t.unit)}</span>
            <span class="trade-flow-change ${s}">${a} ${Math.abs(t.changePct).toFixed(1)}%</span>
          </div>
          <div class="trade-restriction-body">
            ${n}
          </div>
        </div>`}).join("")}
    </div>`}renderSparkline(t){if(t.length<2)return"";const s=Math.min(...t),n=Math.max(...t)-s||1,r=200,p=40,l=t.map((h,u)=>{const m=u/(t.length-1)*r,v=p-(h-s)/n*p;return`${m.toFixed(1)},${v.toFixed(1)}`}).join(" ");return`<svg width="${r}" height="${p}" viewBox="0 0 ${r} ${p}" style="display:block;margin:4px 0">
      <polyline points="${l}" fill="none" stroke="var(--accent-primary, #4fc3f7)" stroke-width="1.5" />
    </svg>`}renderMinerals(){if(!this.mineralsData||this.mineralsData.minerals.length===0)return`<div class="economic-empty">${i("components.supplyChain.noMinerals")}</div>`;const t=this.mineralsData.minerals.map(s=>{const a=s.riskRating==="critical"?"sc-risk-critical":s.riskRating==="high"?"sc-risk-high":s.riskRating==="moderate"?"sc-risk-moderate":"sc-risk-low",n=s.topProducers.slice(0,3).map(r=>`${e(r.country)} ${r.sharePct.toFixed(0)}%`).join(", ");return`<tr>
        <td>${e(s.mineral)}</td>
        <td>${n}</td>
        <td>${s.hhi.toFixed(0)}</td>
        <td><span class="${a}">${e(s.riskRating)}</span></td>
      </tr>`}).join("");return`<div class="trade-tariffs-table">
      <table>
        <thead>
          <tr>
            <th>${i("components.supplyChain.mineral")}</th>
            <th>${i("components.supplyChain.topProducers")}</th>
            <th>HHI</th>
            <th>${i("components.supplyChain.risk")}</th>
          </tr>
        </thead>
        <tbody>${t}</tbody>
      </table>
    </div>`}}export{P as SupplyChainPanel};
