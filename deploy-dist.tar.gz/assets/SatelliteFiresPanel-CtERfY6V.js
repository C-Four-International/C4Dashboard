var h=Object.defineProperty;var d=(o,s,t)=>s in o?h(o,s,{enumerable:!0,configurable:!0,writable:!0,value:t}):o[s]=t;var l=(o,s,t)=>d(o,typeof s!="symbol"?s+"":s,t);import{P as p}from"./sanitize-D3oJtyS4.js";import{a as e}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";class v extends p{constructor(){super({id:"satellite-fires",title:e("panels.satelliteFires"),showCount:!0,trackActivity:!0,infoTooltip:e("components.satelliteFires.infoTooltip")});l(this,"stats",[]);l(this,"totalCount",0);l(this,"lastUpdated",null);this.showLoading(e("common.scanningThermalData"))}update(t,n){const a=this.totalCount;this.stats=t,this.totalCount=n,this.lastUpdated=new Date,this.setCount(n),a>0&&n>a&&this.setNewBadge(n-a),this.render()}render(){if(this.stats.length===0){this.setContent(`<div class="panel-empty">${e("common.noDataAvailable")}</div>`);return}const t=this.stats.map(i=>{const r=i.totalFrp>=1e3?`${(i.totalFrp/1e3).toFixed(1)}k`:Math.round(i.totalFrp).toLocaleString();return`<tr class="fire-row${i.highIntensityCount>0?" fires-high":""}">
        <td class="fire-region">${u(i.region)}</td>
        <td class="fire-count">${i.fireCount}</td>
        <td class="fire-hi">${i.highIntensityCount}</td>
        <td class="fire-frp">${r}</td>
      </tr>`}).join(""),n=this.stats.reduce((i,r)=>i+r.totalFrp,0),a=this.stats.reduce((i,r)=>i+r.highIntensityCount,0),c=this.lastUpdated?f(this.lastUpdated):e("components.satelliteFires.never");this.setContent(`
      <div class="fires-panel-content">
        <table class="fires-table">
          <thead>
            <tr>
              <th>${e("components.satelliteFires.region")}</th>
              <th>${e("components.satelliteFires.fires")}</th>
              <th>${e("components.satelliteFires.high")}</th>
              <th>FRP</th>
            </tr>
          </thead>
          <tbody>${t}</tbody>
          <tfoot>
            <tr class="fire-totals">
              <td>${e("components.satelliteFires.total")}</td>
              <td>${this.totalCount}</td>
              <td>${a}</td>
              <td>${n>=1e3?`${(n/1e3).toFixed(1)}k`:Math.round(n).toLocaleString()}</td>
            </tr>
          </tfoot>
        </table>
        <div class="fires-footer">
          <span class="fires-source">NASA FIRMS (VIIRS SNPP)</span>
          <span class="fires-updated">${c}</span>
        </div>
      </div>
    `)}}function u(o){return o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function f(o){const s=Math.floor((Date.now()-o.getTime())/1e3);if(s<60)return e("components.satelliteFires.time.justNow");const t=Math.floor(s/60);if(t<60)return e("components.satelliteFires.time.minutesAgo",{count:String(t)});const n=Math.floor(t/60);return e("components.satelliteFires.time.hoursAgo",{count:String(n)})}export{v as SatelliteFiresPanel};
