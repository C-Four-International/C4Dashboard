var v=Object.defineProperty;var y=(a,o,t)=>o in a?v(a,o,{enumerable:!0,configurable:!0,writable:!0,value:t}):a[o]=t;var l=(a,o,t)=>y(a,typeof o!="symbol"?o+"":o,t);import{P as b,s as d,e as r}from"./sanitize-D3oJtyS4.js";import"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";class f extends b{constructor(){super({id:"spotlight",title:"Today's Hero",trackActivity:!1});l(this,"onLocationRequest");this.content.innerHTML=`<div class="hero-card-loading">Loading today's hero...</div>`}setHeroStory(t){if(!t){this.content.innerHTML='<div class="hero-card-empty">No hero story available today</div>';return}const h=t.imageUrl?`<div class="hero-card-image"><img src="${d(t.imageUrl)}" alt="" loading="lazy" onerror="this.parentElement.style.display='none'"></div>`:"",p=t.pubDate.toLocaleDateString(void 0,{month:"short",day:"numeric",year:"numeric"}),n=t.lat!==void 0&&t.lon!==void 0,u=n?`<button class="hero-card-location-btn" data-lat="${t.lat}" data-lon="${t.lon}" type="button">Show on map</button>`:"";if(this.content.innerHTML=`<div class="hero-card">
  ${h}
  <div class="hero-card-body">
    <span class="hero-card-source">${r(t.source)}</span>
    <h3 class="hero-card-title">
      <a href="${d(t.link)}" target="_blank" rel="noopener">${r(t.title)}</a>
    </h3>
    <span class="hero-card-time">${r(p)}</span>
    ${u}
  </div>
</div>`,n){const e=this.content.querySelector(".hero-card-location-btn");e&&e.addEventListener("click",()=>{var c;const s=Number(e.getAttribute("data-lat")),i=Number(e.getAttribute("data-lon"));!isNaN(s)&&!isNaN(i)&&((c=this.onLocationRequest)==null||c.call(this,s,i))})}}destroy(){this.onLocationRequest=void 0,super.destroy()}}export{f as HeroSpotlightPanel};
