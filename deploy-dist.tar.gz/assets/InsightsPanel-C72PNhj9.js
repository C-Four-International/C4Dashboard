var H=Object.defineProperty;var N=($,o,s)=>o in $?H($,o,{enumerable:!0,configurable:!0,writable:!0,value:s}):$[o]=s;var m=($,o,s)=>N($,typeof o!="symbol"?o+"":o,s);import{P as K,S as M,e as C,s as Y}from"./sanitize-D3oJtyS4.js";import{E,F as j,H as _,I as W,J as A,K as U,L as z}from"./main-BS9nt2LU.js";import{a as S,o as I,j as D,h as G,s as Z,W as q}from"./pipelines-data-BE8dV597.js";import{i as V,g as X}from"./LiveNewsPanel-OJY2LGeN.js";import"./deck-stack-BRjwSfZ4.js";import"./maplibre-BoH-_h6q.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";import"./i18n-VWbTNjcU.js";const J=["killed","dead","death","shot","blood","massacre","slaughter","fatalities","casualties","wounded","injured","murdered","execution","crackdown","violent","clashes","gunfire","shooting"],Q=["war","armada","invasion","airstrike","strike","missile","troops","deployed","offensive","artillery","bomb","combat","fleet","warship","carrier","navy","airforce","deployment","mobilization","attack"],ee=["protest","protests","uprising","revolt","revolution","riot","riots","demonstration","unrest","dissent","rebellion","insurgent","overthrow","coup","martial law","curfew","shutdown","blackout"],T=["iran","tehran","russia","moscow","china","beijing","taiwan","ukraine","kyiv","north korea","pyongyang","israel","gaza","west bank","syria","damascus","yemen","hezbollah","hamas","kremlin","pentagon","nato","wagner"],te=["ceo","earnings","stock","startup","data center","datacenter","revenue","quarterly","profit","investor","ipo","funding","valuation"];class se{constructor(){m(this,"lastReport",null);m(this,"recentEmbeddings",new Map);m(this,"analysisCount",0)}async analyzeHeadlines(o){const s=performance.now();this.analysisCount++,console.group(`%c🔬 Parallel Analysis #${this.analysisCount}`,"color: #6b8afd; font-weight: bold; font-size: 14px"),console.log(`%cAnalyzing ${o.length} headlines...`,"color: #888");const e=[],t=o.map(d=>d.primaryTitle);let i=null,n=null,a=null;if(E.isAvailable){const[d,u,y]=await Promise.all([E.classifySentiment(t).catch(()=>null),E.extractEntities(t).catch(()=>null),this.getEmbeddings(t).catch(()=>null)]);i=d,n=u,a=y,console.log("%c✓ ML models loaded","color: #4ade80"),n&&console.log(`%c  → NER extracted ${n.flat().length} entities`,"color: #888"),a&&console.log(`%c  → Embeddings computed for ${a.length} headlines`,"color: #888")}else console.log("%c⚠ ML not available, using keyword-only analysis","color: #f59e0b");for(let d=0;d<o.length;d++){const u=o[d],y=u.primaryTitle,f=y.toLowerCase(),p=[];p.push(this.scoreByKeywords(f,u));const b=i==null?void 0:i[d];b&&p.push(this.scoreBySentiment(b));const w=n==null?void 0:n[d];w&&p.push(this.scoreByEntities(w));const k=a==null?void 0:a[d];k&&p.push(await this.scoreByNovelty(y,k)),p.push(this.scoreByVelocity(u)),p.push(this.scoreBySourceDiversity(u));const{finalScore:R,confidence:B,disagreement:F}=this.aggregateScores(p),O=F>.3||R>.5&&this.isLowKeywordScore(p),L=O?F>.3?"High disagreement between perspectives":"ML scores high but keyword score low - potential missed story":void 0;e.push({id:u.id,title:y,sourceCount:u.sourceCount,perspectives:p,finalScore:R,confidence:B,disagreement:F,flagged:O,flagReason:L})}e.sort((d,u)=>u.finalScore-d.finalScore);const r=e.filter(d=>d.confidence>.6).slice(0,10),l=e.filter(d=>d.disagreement>.25).sort((d,u)=>u.disagreement-d.disagreement).slice(0,5),c=e.filter(d=>{var f;const u=((f=d.perspectives.find(p=>p.name==="keywords"))==null?void 0:f.score)??0;return d.perspectives.filter(p=>p.name!=="keywords").reduce((p,b)=>p+b.score,0)/Math.max(1,d.perspectives.length-1)>.5&&u<.3}).slice(0,5),h=this.calculateCorrelations(e),g={timestamp:Date.now(),totalHeadlines:o.length,analyzed:e,topByConsensus:r,topByDisagreement:l,missedByKeywords:c,perspectiveCorrelations:h};return this.lastReport=g,this.logReport(g,performance.now()-s),console.groupEnd(),g}scoreByKeywords(o,s){let e=0;const t=[],i=J.filter(c=>o.includes(c));i.length>0&&(e+=.4+i.length*.1,t.push(`violence(${i.join(",")})`));const n=Q.filter(c=>o.includes(c));n.length>0&&(e+=.3+n.length*.08,t.push(`military(${n.join(",")})`));const a=ee.filter(c=>o.includes(c));a.length>0&&(e+=.25+a.length*.07,t.push(`unrest(${a.join(",")})`));const r=T.filter(c=>o.includes(c));r.length>0&&(e+=.2+r.length*.05,t.push(`flashpoint(${r.join(",")})`)),(i.length>0||a.length>0)&&r.length>0&&(e*=1.3,t.push("combo-bonus"));const l=te.filter(c=>o.includes(c));return l.length>0&&(e*=.4,t.push(`demoted(${l.join(",")})`)),e=Math.min(1,e),{name:"keywords",score:e,confidence:.8,reasoning:t.length>0?t.join(" + "):"no keywords matched"}}scoreBySentiment(o){const e=o.label==="negative"?o.score*.8:(1-o.score)*.3;return{name:"sentiment",score:Math.min(1,e),confidence:o.score,reasoning:`${o.label} (${(o.score*100).toFixed(0)}%) - negative news more important`}}scoreByEntities(o){const s=o.filter(l=>l.type.includes("LOC")),e=o.filter(l=>l.type.includes("PER")),t=o.filter(l=>l.type.includes("ORG")),i=s.filter(l=>T.some(c=>l.text.toLowerCase().includes(c)));let n=0;const a=[];i.length>0?(n+=.4,a.push(`geo-locations(${i.map(l=>l.text).join(",")})`)):s.length>0&&(n+=.15,a.push(`locations(${s.length})`)),e.length>0&&(n+=.1+e.length*.05,a.push(`people(${e.map(l=>l.text).join(",")})`)),t.length>0&&(n+=.1+t.length*.05,a.push(`orgs(${t.map(l=>l.text).join(",")})`));const r=o.length;return r>3&&(n+=.15,a.push(`high-density(${r})`)),{name:"entities",score:Math.min(1,n),confidence:o.length>0?.7:.3,reasoning:a.length>0?a.join(" + "):"no significant entities"}}async scoreByNovelty(o,s){let e=0,t="";for(const[a,r]of this.recentEmbeddings){if(a===o)continue;const l=this.cosineSimilarity(s,r);l>e&&(e=l,t=a.slice(0,50))}if(this.recentEmbeddings.set(o,s),this.recentEmbeddings.size>100){const a=this.recentEmbeddings.keys().next().value;a&&this.recentEmbeddings.delete(a)}const i=1-e,n=i>.5?.3:0;return{name:"novelty",score:Math.min(1,i*.7+n),confidence:.6,reasoning:e>.7?`similar to: "${t}..." (${(e*100).toFixed(0)}%)`:`novel content (${(i*100).toFixed(0)}% unique)`}}scoreByVelocity(o){const s=o.velocity;let e=0,t="";return!s||s.level==="normal"?(e=.2,t="normal velocity"):s.level==="elevated"?(e=.5,t=`elevated: +${s.sourcesPerHour}/hr`):s.level==="spike"?(e=.7,t=`spike: +${s.sourcesPerHour}/hr`):s.level==="viral"&&(e=.9,t=`viral: +${s.sourcesPerHour}/hr`),(s==null?void 0:s.trend)==="rising"&&(e+=.1,t+=" ↑"),{name:"velocity",score:Math.min(1,e),confidence:.8,reasoning:t}}scoreBySourceDiversity(o){const s=o.sourceCount;let e=0,t="";return s>=5?(e=.9,t=`${s} sources - highly confirmed`):s>=3?(e=.7,t=`${s} sources - confirmed`):s>=2?(e=.5,t=`${s} sources - multi-source`):(e=.2,t="single source"),{name:"sources",score:e,confidence:.9,reasoning:t}}aggregateScores(o){if(o.length===0)return{finalScore:0,confidence:0,disagreement:0};const s={keywords:.25,sentiment:.15,entities:.2,novelty:.1,velocity:.15,sources:.15};let e=0,t=0,i=0;for(const g of o){const d=s[g.name]??.1;e+=g.score*d*g.confidence,t+=d,i+=g.confidence}const n=t>0?e/t:0,a=i/o.length,r=o.map(g=>g.score),l=r.reduce((g,d)=>g+d,0)/r.length,c=r.reduce((g,d)=>g+Math.pow(d-l,2),0)/r.length,h=Math.sqrt(c);return{finalScore:n,confidence:a*(1-h*.5),disagreement:h}}isLowKeywordScore(o){var e;return(((e=o.find(t=>t.name==="keywords"))==null?void 0:e.score)??0)<.3}calculateCorrelations(o){const s=["keywords","sentiment","entities","novelty","velocity","sources"],e={};for(let t=0;t<s.length;t++)for(let i=t+1;i<s.length;i++){const n=s[t],a=s[i],r=o.map(h=>{var g;return((g=h.perspectives.find(d=>d.name===n))==null?void 0:g.score)??0}),l=o.map(h=>{var g;return((g=h.perspectives.find(d=>d.name===a))==null?void 0:g.score)??0}),c=this.pearsonCorrelation(r,l);e[`${n}-${a}`]=c}return e}pearsonCorrelation(o,s){const e=o.length;if(e===0)return 0;const t=o.reduce((c,h)=>c+h,0)/e,i=s.reduce((c,h)=>c+h,0)/e;let n=0,a=0,r=0;for(let c=0;c<e;c++){const h=o[c]??0,g=s[c]??0,d=h-t,u=g-i;n+=d*u,a+=d*d,r+=u*u}const l=Math.sqrt(a*r);return l===0?0:n/l}cosineSimilarity(o,s){let e=0,t=0,i=0;for(let a=0;a<o.length;a++){const r=o[a]??0,l=s[a]??0;e+=r*l,t+=r*r,i+=l*l}const n=Math.sqrt(t)*Math.sqrt(i);return n===0?0:e/n}async getEmbeddings(o){return E.embedTexts(o)}logReport(o,s){console.log(`%c⏱ Analysis completed in ${s.toFixed(0)}ms`,"color: #888"),console.log(`
%c📊 TOP BY CONSENSUS (high confidence)`,"color: #4ade80; font-weight: bold"),console.table(o.topByConsensus.slice(0,5).map(t=>{var i;return{score:t.finalScore.toFixed(2),conf:t.confidence.toFixed(2),title:t.title.slice(0,60)+(t.title.length>60?"...":""),topPerspective:(i=t.perspectives.sort((n,a)=>a.score-n.score)[0])==null?void 0:i.name}})),o.topByDisagreement.length>0&&(console.log(`
%c⚠️ HIGH DISAGREEMENT (perspectives conflict)`,"color: #f59e0b; font-weight: bold"),console.table(o.topByDisagreement.map(t=>({disagreement:t.disagreement.toFixed(2),title:t.title.slice(0,50)+"...",perspectives:t.perspectives.map(i=>`${i.name}:${i.score.toFixed(1)}`).join(" | ")})))),o.missedByKeywords.length>0&&(console.log(`
%c🎯 POTENTIALLY MISSED (ML says important, keywords say no)`,"color: #ef4444; font-weight: bold"),o.missedByKeywords.forEach(t=>{var a;const i=((a=t.perspectives.find(r=>r.name==="keywords"))==null?void 0:a.score)??0,n=t.perspectives.filter(r=>r.name!=="keywords");console.log(`  %c"${t.title.slice(0,70)}..."`,"color: #fff"),console.log(`    keywords: ${(i*100).toFixed(0)}% | ML avg: ${(n.reduce((r,l)=>r+l.score,0)/n.length*100).toFixed(0)}%`),n.forEach(r=>{console.log(`      ${r.name}: ${(r.score*100).toFixed(0)}% - ${r.reasoning}`)})})),console.log(`
%c📈 Perspective Correlations`,"color: #6b8afd"),Object.entries(o.perspectiveCorrelations).sort((t,i)=>Math.abs(i[1])-Math.abs(t[1])).slice(0,5).forEach(([t,i])=>{const n=i>.5?"#4ade80":i<-.2?"#ef4444":"#888";console.log(`  %c${t}: ${i.toFixed(2)}`,`color: ${n}`)})}getLastReport(){return this.lastReport}getSuggestedImprovements(){if(!this.lastReport)return[];const o=[];this.lastReport.missedByKeywords.length>2&&o.push("Consider adding more keywords to capture ML-detected important stories"),this.lastReport.analyzed.reduce((i,n)=>i+n.disagreement,0)/this.lastReport.analyzed.length>.25&&o.push("High average disagreement - perspectives may need rebalancing");const{perspectiveCorrelations:e}=this.lastReport;return(e["keywords-sentiment"]??0)<.3&&o.push("Low keyword-sentiment correlation - keyword list may be missing emotional content"),o}}const P=new se,v=class v extends K{constructor(){super({id:"insights",title:S("panels.insights"),showCount:!1,infoTooltip:S("components.insights.infoTooltip")});m(this,"isHidden",!1);m(this,"lastBriefUpdate",0);m(this,"cachedBrief",null);m(this,"lastMissedStories",[]);m(this,"lastConvergenceZones",[]);m(this,"lastFocalPoints",[]);m(this,"lastMilitaryFlights",[]);m(this,"lastClusters",[]);m(this,"aiFlowUnsubscribe",null);m(this,"updateGeneration",0);I()&&(this.hide(),this.isHidden=!0),!D()&&!I()&&(this.aiFlowUnsubscribe=V(s=>{s!=="mapNewsFlash"&&this.onAiFlowChanged()}))}setMilitaryFlights(s){this.lastMilitaryFlights=s}getTheaterPostureContext(){if(this.lastMilitaryFlights.length===0)return"";const e=j(this.lastMilitaryFlights).filter(i=>i.postureLevel==="critical"||i.postureLevel==="elevated"||i.strikeCapable);return e.length===0?"":`

CRITICAL MILITARY POSTURE:
${e.map(i=>{const n=[];return n.push(`${i.theaterName}: ${i.totalAircraft} aircraft`),n.push(`(${i.postureLevel.toUpperCase()})`),i.strikeCapable&&n.push("STRIKE CAPABLE"),n.push(`- ${i.summary}`),i.targetNation&&n.push(`Focus: ${i.targetNation}`),n.join(" ")}).join(`
`)}`}async loadBriefFromCache(){var e;if(this.cachedBrief)return!1;const s=await G(v.BRIEF_CACHE_KEY);return(e=s==null?void 0:s.data)!=null&&e.summary?(this.cachedBrief=s.data.summary,this.lastBriefUpdate=s.updatedAt,!0):!1}getImportanceScore(s){var y;let e=0;const t=s.primaryTitle.toLowerCase();e+=s.sourceCount*10;const i=v.VIOLENCE_KEYWORDS.filter(f=>t.includes(f));i.length>0&&(e+=100+i.length*25);const n=v.MILITARY_KEYWORDS.filter(f=>t.includes(f));n.length>0&&(e+=80+n.length*20);const a=v.UNREST_KEYWORDS.filter(f=>t.includes(f));a.length>0&&(e+=70+a.length*18);const r=v.FLASHPOINT_KEYWORDS.filter(f=>t.includes(f));r.length>0&&(e+=60+r.length*15),(i.length>0||a.length>0)&&r.length>0&&(e*=1.5);const l=v.CRISIS_KEYWORDS.filter(f=>t.includes(f));l.length>0&&(e+=30+l.length*10),v.DEMOTE_KEYWORDS.filter(f=>t.includes(f)).length>0&&(e*=.3),e*={viral:3,spike:2.5,elevated:1.5,normal:1}[((y=s.velocity)==null?void 0:y.level)??"normal"]??1,s.isAlert&&(e+=50);const d=(Date.now()-s.firstSeen.getTime())/36e5,u=Math.max(.5,1-d/12);return e*=u,e}selectTopStories(s,e){const n=s.map(c=>({cluster:c,score:this.getImportanceScore(c)})).filter(({cluster:c,score:h})=>c.sourceCount>=2||c.isAlert||c.velocity&&c.velocity.level!=="normal"||h>100).sort((c,h)=>h.score-c.score),a=[],r=new Map,l=3;for(const{cluster:c}of n){const h=c.primarySource,g=r.get(h)||0;if(g<l&&(a.push(c),r.set(h,g+1)),a.length>=e)break}return a}setProgress(s,e,t){const i=Math.round(s/e*100);this.setContent(`
      <div class="insights-progress">
        <div class="insights-progress-bar">
          <div class="insights-progress-fill" style="width: ${i}%"></div>
        </div>
        <div class="insights-progress-info">
          <span class="insights-progress-step">${S("components.insights.step",{step:String(s),total:String(e)})}</span>
          <span class="insights-progress-message">${t}</span>
        </div>
      </div>
    `)}async updateInsights(s){if(this.isHidden)return;this.lastClusters=s,this.updateGeneration++;const e=this.updateGeneration;if(s.length===0){this.setDataBadge("unavailable"),this.setContent(`<div class="insights-empty">${S("components.insights.waitingForData")}</div>`);return}if(!D()){this.setDataBadge("unavailable"),this.renderDisabledState();return}const t=D()?{cloudLlm:!0,browserModel:!0}:X(),i={skipCloudProviders:!t.cloudLlm,skipBrowserFallback:!t.browserModel},n=4;try{this.setProgress(1,n,S("components.insights.rankingStories"));const a=this.selectTopStories(s,8),r=P.analyzeHeadlines(s).then(p=>{this.lastMissedStories=p.missedByKeywords;const b=P.getSuggestedImprovements();b.length>0&&(console.log("%c💡 Improvement Suggestions:","color: #f59e0b; font-weight: bold"),b.forEach(w=>console.log(`  • ${w}`)))}).catch(p=>{console.warn("[ParallelAnalysis] Error:",p)});let l,c;if(M==="full"?(l=_.getSummary(),this.lastConvergenceZones=l.convergenceZones,l.totalSignals>0&&W(),c=A.analyze(s,l),this.lastFocalPoints=c.focalPoints,c.focalPoints.length>0&&(A.logSummary(),U(s),window.dispatchEvent(new CustomEvent("focal-points-ready")))):(l={timestamp:new Date,totalSignals:0,byType:{},convergenceZones:[],topCountries:[],aiContext:""},c={focalPoints:[],aiContext:"",timestamp:new Date,topCountries:[],topCompanies:[]},this.lastConvergenceZones=[],this.lastFocalPoints=[]),a.length===0){this.setContent(`<div class="insights-empty">${S("components.insights.noStories")}</div>`);return}const h=a.slice(0,5).map(p=>p.primaryTitle);this.setProgress(2,n,S("components.insights.analyzingSentiment"));let g=null;if(E.isAvailable&&(g=await E.classifySentiment(h).catch(()=>null)),this.updateGeneration!==e)return;const d=await this.loadBriefFromCache();if(this.updateGeneration!==e)return;let u=this.cachedBrief;const y=Date.now();let f=d;if(!u||y-this.lastBriefUpdate>v.BRIEF_COOLDOWN_MS){this.setProgress(3,n,S("components.insights.generatingBrief"));const p=M==="full"?this.getTheaterPostureContext():"",b=M==="full"?(c.aiContext||l.aiContext)+p:"",w=await z(h,(k,R,B)=>{this.setProgress(3,n,`Generating brief: ${B}`)},b,void 0,i);if(this.updateGeneration!==e)return;w&&(u=w.summary,this.cachedBrief=u,this.lastBriefUpdate=y,f=!1,Z(v.BRIEF_CACHE_KEY,{summary:u}),console.log(`[InsightsPanel] Brief generated${w.cached?" (cached)":""}${b?" (with geo context)":""}`))}else f=!0,this.setProgress(3,n,"Using cached brief...");if(this.setDataBadge(u?f?"cached":"live":"unavailable"),this.setProgress(4,n,"Multi-perspective analysis..."),await r,this.updateGeneration!==e)return;this.renderInsights(a,g,u)}catch(a){console.error("[InsightsPanel] Error:",a),this.setContent('<div class="insights-error">Analysis failed - retrying...</div>')}}renderInsights(s,e,t){const i=t?this.renderWorldBrief(t):"",n=this.renderFocalPoints(),a=this.renderConvergenceZones(),r=this.renderSentimentOverview(e),l=this.renderBreakingStories(s,e),c=this.renderStats(s),h=this.renderMissedStories();this.setContent(`
      ${i}
      ${n}
      ${a}
      ${r}
      ${c}
      <div class="insights-section">
        <div class="insights-section-title">BREAKING & CONFIRMED</div>
        ${l}
      </div>
      ${h}
    `)}renderWorldBrief(s){return`
      <div class="insights-brief">
        <div class="insights-section-title">${M==="tech"?"🚀 TECH BRIEF":"🌍 WORLD BRIEF"}</div>
        <div class="insights-brief-text">${C(s)}</div>
      </div>
    `}renderBreakingStories(s,e){return s.map((t,i)=>{const n=e==null?void 0:e[i],a=(n==null?void 0:n.label)==="negative"?"negative":(n==null?void 0:n.label)==="positive"?"positive":"neutral",r=[];if(t.sourceCount>=3?r.push(`<span class="insight-badge confirmed">✓ ${t.sourceCount} sources</span>`):t.sourceCount>=2&&r.push(`<span class="insight-badge multi">${t.sourceCount} sources</span>`),t.velocity&&t.velocity.level!=="normal"){const l=t.velocity.trend==="rising"?"↑":"";r.push(`<span class="insight-badge velocity ${t.velocity.level}">${l}+${t.velocity.sourcesPerHour}/hr</span>`)}return t.isAlert&&r.push('<span class="insight-badge alert">⚠ ALERT</span>'),`
        <div class="insight-story">
          <div class="insight-story-header">
            <span class="insight-sentiment-dot ${a}"></span>
            <span class="insight-story-title">${C(t.primaryTitle.slice(0,100))}${t.primaryTitle.length>100?"...":""}</span>
          </div>
          ${r.length>0?`<div class="insight-badges">${r.join("")}</div>`:""}
        </div>
      `}).join("")}renderSentimentOverview(s){if(!s||s.length===0)return"";const e=s.filter(g=>g.label==="negative").length,t=s.filter(g=>g.label==="positive").length,i=s.length-e-t,n=s.length,a=Math.round(e/n*100),r=Math.round(i/n*100),l=100-a-r;let c="Mixed",h="neutral";return e>t+i?(c="Negative",h="negative"):t>e+i&&(c="Positive",h="positive"),`
      <div class="insights-sentiment-bar">
        <div class="sentiment-bar-track">
          <div class="sentiment-bar-negative" style="width: ${a}%"></div>
          <div class="sentiment-bar-neutral" style="width: ${r}%"></div>
          <div class="sentiment-bar-positive" style="width: ${l}%"></div>
        </div>
        <div class="sentiment-bar-labels">
          <span class="sentiment-label negative">${e}</span>
          <span class="sentiment-label neutral">${i}</span>
          <span class="sentiment-label positive">${t}</span>
        </div>
        <div class="sentiment-tone ${h}">Overall: ${c}</div>
      </div>
    `}renderStats(s){const e=s.filter(n=>n.sourceCount>=2).length,t=s.filter(n=>n.velocity&&n.velocity.level!=="normal").length,i=s.filter(n=>n.isAlert).length;return`
      <div class="insights-stats">
        <div class="insight-stat">
          <span class="insight-stat-value">${e}</span>
          <span class="insight-stat-label">Multi-source</span>
        </div>
        <div class="insight-stat">
          <span class="insight-stat-value">${t}</span>
          <span class="insight-stat-label">Fast-moving</span>
        </div>
        ${i>0?`
        <div class="insight-stat alert">
          <span class="insight-stat-value">${i}</span>
          <span class="insight-stat-label">Alerts</span>
        </div>
        `:""}
      </div>
    `}renderMissedStories(){return this.lastMissedStories.length===0?"":`
      <div class="insights-section insights-missed">
        <div class="insights-section-title">🎯 ML DETECTED</div>
        ${this.lastMissedStories.slice(0,3).map(e=>{const t=e.perspectives.filter(a=>a.name!=="keywords").sort((a,r)=>r.score-a.score)[0],i=(t==null?void 0:t.name)??"ml",n=(t==null?void 0:t.score)??0;return`
        <div class="insight-story missed">
          <div class="insight-story-header">
            <span class="insight-sentiment-dot ml-flagged"></span>
            <span class="insight-story-title">${C(e.title.slice(0,80))}${e.title.length>80?"...":""}</span>
          </div>
          <div class="insight-badges">
            <span class="insight-badge ml-detected">🔬 ${i}: ${(n*100).toFixed(0)}%</span>
          </div>
        </div>
      `}).join("")}
      </div>
    `}renderConvergenceZones(){return this.lastConvergenceZones.length===0?"":`
      <div class="insights-section insights-convergence">
        <div class="insights-section-title">📍 GEOGRAPHIC CONVERGENCE</div>
        ${this.lastConvergenceZones.slice(0,3).map(e=>{const t={internet_outage:"🌐",military_flight:"✈️",military_vessel:"🚢",protest:"🪧",ais_disruption:"⚓"};return`
        <div class="convergence-zone">
          <div class="convergence-region">${e.signalTypes.map(n=>t[n]||"📍").join("")} ${C(e.region)}</div>
          <div class="convergence-description">${C(e.description)}</div>
          <div class="convergence-stats">${e.signalTypes.length} signal types • ${e.totalSignals} events</div>
        </div>
      `}).join("")}
      </div>
    `}renderFocalPoints(){const s=this.lastFocalPoints.filter(i=>i.newsMentions>0&&i.signalCount>0).slice(0,5);if(s.length===0)return"";const e={internet_outage:"🌐",military_flight:"✈️",military_vessel:"⚓",protest:"📢",ais_disruption:"🚢"};return`
      <div class="insights-section insights-focal">
        <div class="insights-section-title">🎯 FOCAL POINTS</div>
        ${s.map(i=>{var h;const n=i.urgency,a=i.signalTypes.map(g=>e[g]||"").join(" "),r=i.topHeadlines[0],l=((h=r==null?void 0:r.title)==null?void 0:h.slice(0,60))||"",c=Y((r==null?void 0:r.url)||"");return`
        <div class="focal-point ${n}">
          <div class="focal-point-header">
            <span class="focal-point-name">${C(i.displayName)}</span>
            <span class="focal-point-urgency ${n}">${i.urgency.toUpperCase()}</span>
          </div>
          <div class="focal-point-signals">${a}</div>
          <div class="focal-point-stats">
            ${i.newsMentions} news • ${i.signalCount} signals
          </div>
          ${l&&c?`<a href="${c}" target="_blank" rel="noopener" class="focal-point-headline">"${C(l)}..."</a>`:""}
        </div>
      `}).join("")}
      </div>
    `}renderDisabledState(){this.setContent(`
      <div class="insights-disabled">
        <div class="insights-disabled-icon" style="color: #ef4444; font-size: 24px;">⚠️</div>
        <div class="insights-disabled-title" style="color: #ef4444; font-weight: 700;">AI Functionality Unavailable</div>
        <div class="insights-disabled-hint">Fallback dashboard in operation. AI inference and automated summarization are unavailable.</div>
      </div>
    `)}async onAiFlowChanged(){this.updateGeneration++,this.cachedBrief=null,this.lastBriefUpdate=0;try{await q(v.BRIEF_CACHE_KEY)}catch{}{this.setDataBadge("unavailable"),this.renderDisabledState();return}}destroy(){var s;(s=this.aiFlowUnsubscribe)==null||s.call(this),super.destroy()}};m(v,"BRIEF_COOLDOWN_MS",432e5),m(v,"BRIEF_CACHE_KEY","summary:world-brief"),m(v,"MILITARY_KEYWORDS",["war","armada","invasion","airstrike","strike","missile","troops","deployed","offensive","artillery","bomb","combat","fleet","warship","carrier","navy","airforce","deployment","mobilization","attack"]),m(v,"VIOLENCE_KEYWORDS",["killed","dead","death","shot","blood","massacre","slaughter","fatalities","casualties","wounded","injured","murdered","execution","crackdown","violent","clashes","gunfire","shooting"]),m(v,"UNREST_KEYWORDS",["protest","protests","uprising","revolt","revolution","riot","riots","demonstration","unrest","dissent","rebellion","insurgent","overthrow","coup","martial law","curfew","shutdown","blackout"]),m(v,"FLASHPOINT_KEYWORDS",["iran","tehran","russia","moscow","china","beijing","taiwan","ukraine","kyiv","north korea","pyongyang","israel","gaza","west bank","syria","damascus","yemen","hezbollah","hamas","kremlin","pentagon","nato","wagner"]),m(v,"CRISIS_KEYWORDS",["crisis","emergency","catastrophe","disaster","collapse","humanitarian","sanctions","ultimatum","threat","retaliation","escalation","tensions","breaking","urgent","developing","exclusive"]),m(v,"DEMOTE_KEYWORDS",["ceo","earnings","stock","startup","data center","datacenter","revenue","quarterly","profit","investor","ipo","funding","valuation"]);let x=v;export{x as InsightsPanel};
