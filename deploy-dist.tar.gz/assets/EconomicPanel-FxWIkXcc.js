var f=Object.defineProperty;var y=(c,p,i)=>p in c?f(c,p,{enumerable:!0,configurable:!0,writable:!0,value:i}):c[p]=i;var v=(c,p,i)=>y(c,typeof p!="symbol"?p+"":p,i);import{P as S,i as C,e as a}from"./sanitize-D3oJtyS4.js";import{a as s,j as w,g as $}from"./pipelines-data-BE8dV597.js";import{a as T,f as k,b as R,c as B,d as P}from"./main-BS9nt2LU.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";function b(c){return c>=1e9?`$${(c/1e9).toFixed(1)}B`:c>=1e6?`$${(c/1e6).toFixed(1)}M`:c>=1e3?`$${(c/1e3).toFixed(0)}K`:`$${c.toFixed(0)}`}function x(c){switch(c){case"contract":return"📄";case"grant":return"🎁";case"loan":return"💰";default:return"📋"}}class M extends S{constructor(){super({id:"economic",title:s("panels.economic")});v(this,"fredData",[]);v(this,"oilData",null);v(this,"spendingData",null);v(this,"bisData",null);v(this,"lastUpdate",null);v(this,"activeTab","indicators");this.content.addEventListener("click",i=>{const t=i.target.closest(".economic-tab");t!=null&&t.dataset.tab&&(this.activeTab=t.dataset.tab,this.render())})}update(i){this.fredData=i,this.lastUpdate=new Date,this.render()}updateOil(i){this.oilData=i,this.render()}updateSpending(i){this.spendingData=i,this.render()}updateBis(i){this.bisData=i,this.render()}setLoading(i){i&&this.showLoading()}render(){const i=this.oilData&&(this.oilData.wtiPrice||this.oilData.brentPrice),t=this.spendingData&&this.spendingData.awards.length>0,r=this.bisData&&this.bisData.policyRates.length>0,l=`
      <div class="economic-tabs">
        <button class="economic-tab ${this.activeTab==="indicators"?"active":""}" data-tab="indicators">
          📊 ${s("components.economic.indicators")}
        </button>
        ${i?`
          <button class="economic-tab ${this.activeTab==="oil"?"active":""}" data-tab="oil">
            🛢️ ${s("components.economic.oil")}
          </button>
        `:""}
        ${t?`
          <button class="economic-tab ${this.activeTab==="spending"?"active":""}" data-tab="spending">
            🏛️ ${s("components.economic.gov")}
          </button>
        `:""}
        ${r?`
          <button class="economic-tab ${this.activeTab==="centralBanks"?"active":""}" data-tab="centralBanks">
            🏦 ${s("components.economic.centralBanks")}
          </button>
        `:""}
      </div>
    `;let o="";switch(this.activeTab){case"indicators":o=this.renderIndicators();break;case"oil":o=this.renderOil();break;case"spending":o=this.renderSpending();break;case"centralBanks":o=this.renderCentralBanks();break}const m=this.lastUpdate?this.lastUpdate.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}):"";this.setContent(`
      ${l}
      <div class="economic-content">
        ${o}
      </div>
      <div class="economic-footer">
        <span class="economic-source">${this.getSourceLabel()} • ${m}</span>
      </div>
    `)}getSourceLabel(){switch(this.activeTab){case"indicators":return"FRED";case"oil":return"EIA";case"spending":return"USASpending.gov";case"centralBanks":return"BIS"}}renderIndicators(){return this.fredData.length===0?w()&&!C("economicFred")?`<div class="economic-empty">${s("components.economic.fredKeyMissing")}</div>`:`<div class="economic-empty">${s("components.economic.noIndicatorData")}</div>`:`
      <div class="economic-indicators">
        ${this.fredData.map(i=>{const t=T(i.change),r=k(i.change,i.unit),l=i.change!==null?i.change>0?"▲":i.change<0?"▼":"–":"";return`
            <div class="economic-indicator" data-series="${a(i.id)}">
              <div class="indicator-header">
                <span class="indicator-name">${a(i.name)}</span>
                <span class="indicator-id">${a(i.id)}</span>
              </div>
              <div class="indicator-value">
                <span class="value">${a(String(i.value!==null?i.value:"N/A"))}${a(i.unit)}</span>
                <span class="change ${a(t)}">${a(l)} ${a(r)}</span>
              </div>
              <div class="indicator-date">${a(i.date)}</div>
            </div>
          `}).join("")}
      </div>
    `}renderOil(){if(!this.oilData)return`<div class="economic-empty">${s("components.economic.noOilDataRetry")}</div>`;const i=[this.oilData.wtiPrice,this.oilData.brentPrice,this.oilData.usProduction,this.oilData.usInventory].filter(Boolean);return i.length===0?`<div class="economic-empty">${s("components.economic.noOilMetrics")}</div>`:`
      <div class="economic-indicators oil-metrics">
        ${i.map(t=>{if(!t)return"";const r=R(t.trend),l=B(t.trend,t.name.includes("Production"));return`
            <div class="economic-indicator oil-metric">
              <div class="indicator-header">
                <span class="indicator-name">${a(t.name)}</span>
              </div>
              <div class="indicator-value">
                <span class="value">${a(P(t.current,t.unit))} ${a(t.unit)}</span>
                <span class="change" style="color: ${a(l)}">
                  ${a(r)} ${a(t.changePct>0?"+":"")}${a(String(t.changePct))}%
                </span>
              </div>
              <div class="indicator-date">${s("components.economic.vsPreviousWeek")}</div>
            </div>
          `}).join("")}
      </div>
    `}renderSpending(){if(!this.spendingData||this.spendingData.awards.length===0)return`<div class="economic-empty">${s("components.economic.noSpending")}</div>`;const{awards:i,totalAmount:t,periodStart:r,periodEnd:l}=this.spendingData;return`
      <div class="spending-summary">
        <div class="spending-total">
          ${a(b(t))} ${s("components.economic.in")} ${a(String(i.length))} ${s("components.economic.awards")}
          <span class="spending-period">${a(r)} – ${a(l)}</span>
        </div>
      </div>
      <div class="spending-list">
        ${i.slice(0,8).map(o=>`
          <div class="spending-award">
            <div class="award-header">
              <span class="award-icon">${a(x(o.awardType))}</span>
              <span class="award-amount">${a(b(o.amount))}</span>
            </div>
            <div class="award-recipient">${a(o.recipientName)}</div>
            <div class="award-agency">${a(o.agency)}</div>
            ${o.description?`<div class="award-desc">${a(o.description.slice(0,100))}${o.description.length>100?"...":""}</div>`:""}
          </div>
        `).join("")}
      </div>
    `}renderCentralBanks(){if(!this.bisData||this.bisData.policyRates.length===0)return`<div class="economic-empty">${s("components.economic.noBisData")}</div>`;const i=$("--semantic-normal"),t=$("--semantic-critical"),r=$("--text-dim"),l=[...this.bisData.policyRates].sort((n,e)=>e.rate-n.rate),o=`
      <div class="bis-section">
        <div class="bis-section-title">${s("components.economic.policyRate")}</div>
        <div class="economic-indicators">
          ${l.map(n=>{const e=n.rate-n.previousRate,d=e<0?i:e>0?t:r,h=e<0?s("components.economic.cut"):e>0?s("components.economic.hike"):s("components.economic.hold"),u=e<0?"▼":e>0?"▲":"–";return`
              <div class="economic-indicator">
                <div class="indicator-header">
                  <span class="indicator-name">${a(n.centralBank)}</span>
                  <span class="indicator-id">${a(n.countryCode)}</span>
                </div>
                <div class="indicator-value">
                  <span class="value">${a(String(n.rate))}%</span>
                  <span class="change" style="color: ${a(d)}">${a(u)} ${a(h)}</span>
                </div>
                <div class="indicator-date">${a(n.date)}</div>
              </div>`}).join("")}
        </div>
      </div>
    `;let m="";this.bisData.exchangeRates.length>0&&(m=`
        <div class="bis-section">
          <div class="bis-section-title">${s("components.economic.realEer")}</div>
          <div class="economic-indicators">
            ${this.bisData.exchangeRates.map(n=>{const e=n.realChange>0?t:n.realChange<0?i:r,d=n.realChange>0?"▲":n.realChange<0?"▼":"–";return`
                <div class="economic-indicator">
                  <div class="indicator-header">
                    <span class="indicator-name">${a(n.countryName)}</span>
                    <span class="indicator-id">${a(n.countryCode)}</span>
                  </div>
                  <div class="indicator-value">
                    <span class="value">${a(String(n.realEer))}</span>
                    <span class="change" style="color: ${a(e)}">${a(d)} ${a(n.realChange>0?"+":"")}${a(String(n.realChange))}%</span>
                  </div>
                  <div class="indicator-date">${a(n.date)}</div>
                </div>`}).join("")}
          </div>
        </div>
      `);let g="";if(this.bisData.creditToGdp.length>0){const n=[...this.bisData.creditToGdp].sort((e,d)=>d.creditGdpRatio-e.creditGdpRatio);g=`
        <div class="bis-section">
          <div class="bis-section-title">${s("components.economic.creditToGdp")}</div>
          <div class="economic-indicators">
            ${n.map(e=>{const d=e.creditGdpRatio-e.previousRatio,h=d>0?t:d<0?i:r,u=d>0?"▲":d<0?"▼":"–",D=d!==0?`${d>0?"+":""}${Math.round(d*10)/10}pp`:"–";return`
                <div class="economic-indicator">
                  <div class="indicator-header">
                    <span class="indicator-name">${a(e.countryName)}</span>
                    <span class="indicator-id">${a(e.countryCode)}</span>
                  </div>
                  <div class="indicator-value">
                    <span class="value">${a(String(e.creditGdpRatio))}%</span>
                    <span class="change" style="color: ${a(h)}">${a(u)} ${a(D)}</span>
                  </div>
                  <div class="indicator-date">${a(e.date)}</div>
                </div>`}).join("")}
          </div>
        </div>
      `}return o+m+g}}export{M as EconomicPanel};
