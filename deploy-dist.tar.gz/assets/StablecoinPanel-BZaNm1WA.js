var d=Object.defineProperty;var m=(s,i,t)=>i in s?d(s,i,{enumerable:!0,configurable:!0,writable:!0,value:t}):s[i]=t;var o=(s,i,t)=>m(s,typeof i!="symbol"?i+"":i,t);import{P as b,e as r}from"./sanitize-D3oJtyS4.js";import{a as n}from"./pipelines-data-BE8dV597.js";import{M as u}from"./main-BS9nt2LU.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";function c(s){return s>=1e12?`$${(s/1e12).toFixed(1)}T`:s>=1e9?`$${(s/1e9).toFixed(1)}B`:s>=1e6?`$${(s/1e6).toFixed(0)}M`:`$${s.toLocaleString()}`}function v(s){return s==="ON PEG"?"peg-on":s==="SLIGHT DEPEG"?"peg-slight":"peg-off"}function f(s){return s==="HEALTHY"?"health-good":s==="CAUTION"?"health-caution":"health-warning"}class k extends b{constructor(){super({id:"stablecoins",title:n("panels.stablecoins"),showCount:!1});o(this,"data",null);o(this,"loading",!0);o(this,"error",null);o(this,"refreshInterval",null);this.fetchData(),this.refreshInterval=setInterval(()=>this.fetchData(),3*6e4)}destroy(){this.refreshInterval&&(clearInterval(this.refreshInterval),this.refreshInterval=null)}async fetchData(){for(let t=0;t<3;t++)try{const a=new u("",{fetch:(...l)=>globalThis.fetch(...l)});if(this.data=await a.listStablecoinMarkets({coins:[]}),this.error=null,this.data&&this.data.stablecoins.length===0&&t<2){this.showRetrying(),await new Promise(l=>setTimeout(l,2e4));continue}break}catch(a){if(this.isAbortError(a))return;if(t<2){this.showRetrying(),await new Promise(l=>setTimeout(l,2e4));continue}this.error=a instanceof Error?a.message:"Failed to fetch"}this.loading=!1,this.renderPanel()}renderPanel(){if(this.loading){this.showLoading(n("common.loadingStablecoins"));return}if(this.error||!this.data){this.showError(this.error||n("common.noDataShort"));return}const t=this.data;if(!t.stablecoins.length){this.setContent(`<div class="panel-loading-text">${n("components.stablecoins.unavailable")}</div>`);return}const a=t.summary||{totalMarketCap:0,totalVolume24h:0,healthStatus:"UNAVAILABLE"},l=t.stablecoins.map(e=>`
      <div class="stable-row">
        <div class="stable-info">
          <span class="stable-symbol">${r(e.symbol)}</span>
          <span class="stable-name">${r(e.name)}</span>
        </div>
        <div class="stable-price">$${e.price.toFixed(4)}</div>
        <div class="stable-peg ${v(e.pegStatus)}">
          <span class="peg-badge">${r(e.pegStatus)}</span>
          <span class="peg-dev">${e.deviation.toFixed(2)}%</span>
        </div>
      </div>
    `).join(""),h=t.stablecoins.map(e=>`
      <div class="stable-supply-row">
        <span class="stable-symbol">${r(e.symbol)}</span>
        <span class="stable-mcap">${c(e.marketCap)}</span>
        <span class="stable-vol">${c(e.volume24h)}</span>
        <span class="stable-change ${e.change24h>=0?"change-positive":"change-negative"}">${e.change24h>=0?"+":""}${e.change24h.toFixed(2)}%</span>
      </div>
    `).join(""),p=`
      <div class="stablecoin-container">
        <div class="stable-health ${f(a.healthStatus)}">
          <span class="health-label">${r(a.healthStatus)}</span>
          <span class="health-detail">MCap: ${c(a.totalMarketCap)} | Vol: ${c(a.totalVolume24h)}</span>
        </div>
        <div class="stable-section">
          <div class="stable-section-title">${n("components.stablecoins.pegHealth")}</div>
          <div class="stable-peg-list">${l}</div>
        </div>
        <div class="stable-section">
          <div class="stable-section-title">${n("components.stablecoins.supplyVolume")}</div>
          <div class="stable-supply-header">
            <span>${n("components.stablecoins.token")}</span><span>${n("components.stablecoins.mcap")}</span><span>${n("components.stablecoins.vol24h")}</span><span>${n("components.stablecoins.chg24h")}</span>
          </div>
          <div class="stable-supply-list">${h}</div>
        </div>
      </div>
    `;this.setContent(p)}}export{k as StablecoinPanel};
