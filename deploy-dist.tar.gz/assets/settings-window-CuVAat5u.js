import{e as p}from"./sanitize-D3oJtyS4.js";import{c as g}from"./LiveNewsPanel-OJY2LGeN.js";import{D as u}from"./main-BS9nt2LU.js";import{a,F as f,j as v,C as w}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./maplibre-BoH-_h6q.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";import"./i18n-VWbTNjcU.js";function E(t,n){if(t==="runtime-config")return a("modals.runtimeConfig.title");const i=`panels.${t.replace(/-([a-z])/g,(m,l)=>l.toUpperCase())}`,s=a(i);return s===i?n:s}function D(){var s;const t=document.getElementById("app");if(!t)return;document.title=`${a("header.settings")} - C⁴ Monitoring Dashboard`;let n=f(g.panels,u);const c=v();function i(){const l=Object.entries(n).filter(([e])=>e!=="runtime-config"||c).map(([e,o])=>`
        <div class="panel-toggle-item ${o.enabled?"active":""}" data-panel="${e}">
          <div class="panel-toggle-checkbox">${o.enabled?"✓":""}</div>
          <span class="panel-toggle-label">${E(e,o.name)}</span>
        </div>
      `).join(""),d=document.getElementById("panelToggles");d&&(d.innerHTML=l,d.querySelectorAll(".panel-toggle-item").forEach(e=>{e.addEventListener("click",()=>{const o=e.dataset.panel,r=n[o];r&&(r.enabled=!r.enabled,w(g.panels,n),i())})}))}t.innerHTML=`
    <div class="settings-window-shell">
      <div class="settings-window-header">
        <div class="settings-window-header-text">
          <span class="settings-window-title">${p(a("header.settings"))}</span>
          <p class="settings-window-caption">${p(a("header.panelDisplayCaption"))}</p>
        </div>
        <button type="button" class="modal-close" id="settingsWindowClose">×</button>
      </div>
      <div class="panel-toggle-grid" id="panelToggles"></div>
    </div>
  `,(s=document.getElementById("settingsWindowClose"))==null||s.addEventListener("click",()=>{window.close()}),i()}export{D as initSettingsWindow};
