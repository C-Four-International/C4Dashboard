var h=Object.defineProperty;var d=(t,n,s)=>n in t?h(t,n,{enumerable:!0,configurable:!0,writable:!0,value:s}):t[n]=s;var r=(t,n,s)=>d(t,typeof n!="symbol"?n+"":n,s);import{P as w,e as f}from"./sanitize-D3oJtyS4.js";import{a as e}from"./pipelines-data-BE8dV597.js";import{M as p}from"./main-BS9nt2LU.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";function i(t){return Math.abs(t)>=1e9?`${(t/1e9).toFixed(1)}B`:Math.abs(t)>=1e6?`${(t/1e6).toFixed(1)}M`:Math.abs(t)>=1e3?`${(t/1e3).toFixed(0)}K`:t.toLocaleString()}function c(t){return t==="inflow"?"flow-inflow":t==="outflow"?"flow-outflow":"flow-neutral"}function $(t){return t>.1?"change-positive":t<-.1?"change-negative":"change-neutral"}class M extends w{constructor(){super({id:"etf-flows",title:e("panels.etfFlows"),showCount:!1});r(this,"data",null);r(this,"loading",!0);r(this,"error",null);r(this,"refreshInterval",null);setTimeout(()=>void this.fetchData(),8e3),this.refreshInterval=setInterval(()=>this.fetchData(),3*6e4)}destroy(){this.refreshInterval&&(clearInterval(this.refreshInterval),this.refreshInterval=null)}async fetchData(){for(let s=0;s<3;s++)try{const o=new p("",{fetch:(...l)=>globalThis.fetch(...l)});if(this.data=await o.listEtfFlows({}),this.error=null,this.data&&this.data.etfs.length===0&&!this.data.rateLimited&&s<2){this.showRetrying(),await new Promise(l=>setTimeout(l,2e4));continue}break}catch(o){if(this.isAbortError(o))return;if(s<2){this.showRetrying(),await new Promise(l=>setTimeout(l,2e4));continue}this.error=o instanceof Error?o.message:"Failed to fetch"}this.loading=!1,this.renderPanel()}renderPanel(){if(this.loading){this.showLoading(e("common.loadingEtfData"));return}if(this.error||!this.data){this.showError(this.error||e("common.noDataShort"));return}const s=this.data;if(!s.etfs.length){const a=s.rateLimited?e("components.etfFlows.rateLimited"):e("components.etfFlows.unavailable");this.setContent(`<div class="panel-loading-text">${a}</div>`);return}const o=s.summary||{totalVolume:0,totalEstFlow:0,netDirection:"NEUTRAL",inflowCount:0,outflowCount:0},l=o.netDirection.includes("INFLOW")?"flow-inflow":o.netDirection.includes("OUTFLOW")?"flow-outflow":"flow-neutral",m=s.etfs.map(a=>`
      <tr class="etf-row ${c(a.direction)}">
        <td class="etf-ticker">${f(a.ticker)}</td>
        <td class="etf-issuer">${f(a.issuer)}</td>
        <td class="etf-flow ${c(a.direction)}">${a.direction==="inflow"?"+":a.direction==="outflow"?"-":""}$${i(Math.abs(a.estFlow))}</td>
        <td class="etf-volume">${i(a.volume)}</td>
        <td class="etf-change ${$(a.priceChange)}">${a.priceChange>0?"+":""}${a.priceChange.toFixed(2)}%</td>
      </tr>
    `).join(""),u=`
      <div class="etf-flows-container">
        <div class="etf-summary ${l}">
          <div class="etf-summary-item">
            <span class="etf-summary-label">${e("components.etfFlows.netFlow")}</span>
            <span class="etf-summary-value ${l}">${o.netDirection.includes("INFLOW")?e("components.etfFlows.netInflow"):e("components.etfFlows.netOutflow")}</span>
          </div>
          <div class="etf-summary-item">
            <span class="etf-summary-label">${e("components.etfFlows.estFlow")}</span>
            <span class="etf-summary-value">$${i(Math.abs(o.totalEstFlow))}</span>
          </div>
          <div class="etf-summary-item">
            <span class="etf-summary-label">${e("components.etfFlows.totalVol")}</span>
            <span class="etf-summary-value">${i(o.totalVolume)}</span>
          </div>
          <div class="etf-summary-item">
            <span class="etf-summary-label">${e("components.etfFlows.etfs")}</span>
            <span class="etf-summary-value">${o.inflowCount}↑ ${o.outflowCount}↓</span>
          </div>
        </div>
        <div class="etf-table-wrap">
          <table class="etf-table">
            <thead>
              <tr>
                <th>${e("components.etfFlows.table.ticker")}</th>
                <th>${e("components.etfFlows.table.issuer")}</th>
                <th>${e("components.etfFlows.table.estFlow")}</th>
                <th>${e("components.etfFlows.table.volume")}</th>
                <th>${e("components.etfFlows.table.change")}</th>
              </tr>
            </thead>
            <tbody>${m}</tbody>
          </table>
        </div>
      </div>
    `;this.setContent(u)}}export{M as ETFFlowsPanel};
