import{P as o,e as r}from"./sanitize-D3oJtyS4.js";import{a as i,O as f,Q as m,R as l,T as p}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";function c(n,t,s=50,a=16){if(!n||n.length<2)return"";const e=Math.min(...n),d=Math.max(...n)-e||1,h=t!=null&&t>=0?"var(--green)":"var(--red)",v=n.map((g,$)=>{const k=$/(n.length-1)*s,u=a-(g-e)/d*(a-2)-1;return`${k.toFixed(1)},${u.toFixed(1)}`}).join(" ");return`<svg width="${s}" height="${a}" viewBox="0 0 ${s} ${a}" class="mini-sparkline"><polyline points="${v}" fill="none" stroke="${h}" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`}class M extends o{constructor(){super({id:"markets",title:i("panels.markets")})}renderMarkets(t,s){if(t.length===0){this.showError(s?i("common.rateLimitedMarket"):i("common.failedMarketData"));return}const a=t.map(e=>`
      <div class="market-item">
        <div class="market-info">
          <span class="market-name">${r(e.name)}</span>
          <span class="market-symbol">${r(e.display)}</span>
        </div>
        <div class="market-data">
          ${c(e.sparkline,e.change)}
          <span class="market-price">${p(e.price)}</span>
          <span class="market-change ${m(e.change)}">${l(e.change)}</span>
        </div>
      </div>
    `).join("");this.setContent(a)}}class w extends o{constructor(){super({id:"heatmap",title:i("panels.heatmap")})}renderHeatmap(t){const s=t.filter(e=>e.change!==null);if(s.length===0){this.showError(i("common.failedSectorData"));return}const a='<div class="heatmap">'+s.map(e=>`
        <div class="heatmap-cell ${f(e.change)}">
          <div class="sector-name">${r(e.name)}</div>
          <div class="sector-change ${m(e.change)}">${l(e.change)}</div>
        </div>
      `).join("")+"</div>";this.setContent(a)}}class D extends o{constructor(){super({id:"commodities",title:i("panels.commodities")})}renderCommodities(t){const s=t.filter(e=>e.price!==null);if(s.length===0){this.showError(i("common.failedCommodities"));return}const a='<div class="commodities-grid">'+s.map(e=>`
        <div class="commodity-item">
          <div class="commodity-name">${r(e.display)}</div>
          ${c(e.sparkline,e.change,60,18)}
          <div class="commodity-price">${p(e.price)}</div>
          <div class="commodity-change ${m(e.change)}">${l(e.change)}</div>
        </div>
      `).join("")+"</div>";this.setContent(a)}}class E extends o{constructor(){super({id:"crypto",title:i("panels.crypto")})}renderCrypto(t){if(t.length===0){this.showError(i("common.failedCryptoData"));return}const s=t.map(a=>`
      <div class="market-item">
        <div class="market-info">
          <span class="market-name">${r(a.name)}</span>
          <span class="market-symbol">${r(a.symbol)}</span>
        </div>
        <div class="market-data">
          ${c(a.sparkline,a.change)}
          <span class="market-price">$${a.price.toLocaleString()}</span>
          <span class="market-change ${m(a.change)}">${l(a.change)}</span>
        </div>
      </div>
    `).join("");this.setContent(s)}}export{D as CommoditiesPanel,E as CryptoPanel,w as HeatmapPanel,M as MarketPanel};
