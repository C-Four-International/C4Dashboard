var g=Object.defineProperty;var L=(n,a,s)=>a in n?g(n,a,{enumerable:!0,configurable:!0,writable:!0,value:s}):n[a]=s;var m=(n,a,s)=>L(n,typeof a!="symbol"?a+"":a,s);import{P as A,e as r}from"./sanitize-D3oJtyS4.js";import{G as f}from"./main-BS9nt2LU.js";import{a as e}from"./pipelines-data-BE8dV597.js";import"./deck-stack-BRjwSfZ4.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";import"./i18n-VWbTNjcU.js";function y(n){return{ports:e("components.investments.sectors.ports"),pipelines:e("components.investments.sectors.pipelines"),energy:e("components.investments.sectors.energy"),datacenters:e("components.investments.sectors.datacenters"),airports:e("components.investments.sectors.airports"),railways:e("components.investments.sectors.railways"),telecoms:e("components.investments.sectors.telecoms"),water:e("components.investments.sectors.water"),logistics:e("components.investments.sectors.logistics"),mining:e("components.investments.sectors.mining"),"real-estate":e("components.investments.sectors.realEstate"),manufacturing:e("components.investments.sectors.manufacturing")}[n]||n}const C={operational:"#22c55e","under-construction":"#f59e0b",announced:"#60a5fa",rumoured:"#a78bfa",cancelled:"#ef4444",divested:"#6b7280"},b={SA:"🇸🇦",UAE:"🇦🇪"};function S(n){return n===void 0?e("components.investments.undisclosed"):n>=1e5?`$${(n/1e3).toFixed(0)}B`:n>=1e3?`$${(n/1e3).toFixed(1)}B`:`$${n.toLocaleString()}M`}class K extends A{constructor(s){super({id:"gcc-investments",title:e("panels.gccInvestments"),showCount:!0,infoTooltip:e("components.investments.infoTooltip")});m(this,"filters",{investingCountry:"ALL",sector:"ALL",entity:"ALL",status:"ALL",search:""});m(this,"sortKey","assetName");m(this,"sortAsc",!0);m(this,"onInvestmentClick");this.onInvestmentClick=s,this.setupEventDelegation(),this.render()}getFiltered(){const{investingCountry:s,sector:o,entity:c,status:i,search:l}=this.filters,d=l.toLowerCase();return f.filter(t=>!(s!=="ALL"&&t.investingCountry!==s||o!=="ALL"&&t.sector!==o||c!=="ALL"&&t.investingEntity!==c||i!=="ALL"&&t.status!==i||d&&!t.assetName.toLowerCase().includes(d)&&!t.targetCountry.toLowerCase().includes(d)&&!t.description.toLowerCase().includes(d)&&!t.investingEntity.toLowerCase().includes(d))).sort((t,v)=>{const p=this.sortKey,u=t[p]??"",h=v[p]??"",$=u<h?-1:u>h?1:0;return this.sortAsc?$:-$})}render(){const s=this.getFiltered(),o=Array.from(new Set(f.map(t=>t.investingEntity))).sort(),c=Array.from(new Set(f.map(t=>t.sector))).sort(),i=t=>this.sortKey===t?this.sortAsc?" ↑":" ↓":"",l=s.map(t=>{const v=C[t.status]||"#6b7280",p=b[t.investingCountry]||"",u=y(t.sector);return`
        <tr class="fdi-row" data-id="${r(t.id)}" style="cursor:pointer">
          <td class="fdi-asset">
            <span class="fdi-flag">${p}</span>
            <strong>${r(t.assetName)}</strong>
            <div class="fdi-entity-sub">${r(t.investingEntity)}</div>
          </td>
          <td>${r(t.targetCountry)}</td>
          <td><span class="fdi-sector-badge">${r(u)}</span></td>
          <td><span class="fdi-status-dot" style="background:${v}"></span>${r(t.status)}</td>
          <td class="fdi-usd">${r(S(t.investmentUSD))}</td>
          <td>${t.yearAnnounced??t.yearOperational??"—"}</td>
        </tr>`}).join(""),d=`
      <div class="fdi-toolbar">
        <input
          class="fdi-search"
          type="text"
          placeholder="${e("components.investments.searchPlaceholder")}"
          value="${r(this.filters.search)}"
        />
        <select class="fdi-filter" data-filter="investingCountry">
          <option value="ALL">🌐 ${e("components.investments.allCountries")}</option>
          <option value="SA" ${this.filters.investingCountry==="SA"?"selected":""}>🇸🇦 ${e("components.investments.saudiArabia")}</option>
          <option value="UAE" ${this.filters.investingCountry==="UAE"?"selected":""}>🇦🇪 ${e("components.investments.uae")}</option>
        </select>
        <select class="fdi-filter" data-filter="sector">
          <option value="ALL">${e("components.investments.allSectors")}</option>
          ${c.map(t=>`<option value="${t}" ${this.filters.sector===t?"selected":""}>${r(y(t))}</option>`).join("")}
        </select>
        <select class="fdi-filter" data-filter="entity">
          <option value="ALL">${e("components.investments.allEntities")}</option>
          ${o.map(t=>`<option value="${r(t)}" ${this.filters.entity===t?"selected":""}>${r(t)}</option>`).join("")}
        </select>
        <select class="fdi-filter" data-filter="status">
          <option value="ALL">${e("components.investments.allStatuses")}</option>
          <option value="operational" ${this.filters.status==="operational"?"selected":""}>${e("components.investments.operational")}</option>
          <option value="under-construction" ${this.filters.status==="under-construction"?"selected":""}>${e("components.investments.underConstruction")}</option>
          <option value="announced" ${this.filters.status==="announced"?"selected":""}>${e("components.investments.announced")}</option>
          <option value="rumoured" ${this.filters.status==="rumoured"?"selected":""}>${e("components.investments.rumoured")}</option>
          <option value="divested" ${this.filters.status==="divested"?"selected":""}>${e("components.investments.divested")}</option>
        </select>
      </div>
      <div class="fdi-table-wrap">
        <table class="fdi-table">
          <thead>
            <tr>
              <th class="fdi-sort" data-sort="assetName">${e("components.investments.asset")}${i("assetName")}</th>
              <th class="fdi-sort" data-sort="targetCountry">${e("components.investments.country")}${i("targetCountry")}</th>
              <th class="fdi-sort" data-sort="sector">${e("components.investments.sector")}${i("sector")}</th>
              <th class="fdi-sort" data-sort="status">${e("components.investments.status")}${i("status")}</th>
              <th class="fdi-sort" data-sort="investmentUSD">${e("components.investments.investment")}${i("investmentUSD")}</th>
              <th class="fdi-sort" data-sort="yearAnnounced">${e("components.investments.year")}${i("yearAnnounced")}</th>
            </tr>
          </thead>
          <tbody>${l||`<tr><td colspan="6" class="fdi-empty">${e("components.investments.noMatch")}</td></tr>`}</tbody>
        </table>
      </div>`;this.setContent(d),this.countEl&&(this.countEl.textContent=String(s.length))}setupEventDelegation(){this.content.addEventListener("input",s=>{const o=s.target;o.classList.contains("fdi-search")&&(this.filters.search=o.value,this.render())}),this.content.addEventListener("change",s=>{const o=s.target.closest(".fdi-filter");if(o){const c=o.dataset.filter;this.filters[c]=o.value,this.render()}}),this.content.addEventListener("click",s=>{const o=s.target,c=o.closest(".fdi-sort");if(c){const l=c.dataset.sort;this.sortKey===l?this.sortAsc=!this.sortAsc:(this.sortKey=l,this.sortAsc=!0),this.render();return}const i=o.closest(".fdi-row");if(i){const l=f.find(d=>d.id===i.dataset.id);l&&this.onInvestmentClick&&this.onInvestmentClick(l)}})}}export{K as InvestmentsPanel};
