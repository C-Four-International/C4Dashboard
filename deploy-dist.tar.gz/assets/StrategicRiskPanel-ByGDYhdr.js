var p=Object.defineProperty;var g=(h,d,s)=>d in h?p(h,d,{enumerable:!0,configurable:!0,writable:!0,value:s}):h[d]=s;var l=(h,d,s)=>g(h,typeof d!="symbol"?d+"":d,s);import{P as f,e as m}from"./sanitize-D3oJtyS4.js";import{a as e,g as c}from"./pipelines-data-BE8dV597.js";import{l as u,m as $,n as b,o as R,p as k,q as w,r as S,s as y,t as C}from"./main-BS9nt2LU.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";class M extends f{constructor(){super({id:"strategic-risk",title:e("panels.strategicRisk"),showCount:!1,trackActivity:!0,infoTooltip:e("components.strategicRisk.infoTooltip")});l(this,"overview",null);l(this,"alerts",[]);l(this,"convergenceAlerts",[]);l(this,"freshnessSummary",null);l(this,"refreshInterval",null);l(this,"unsubscribeFreshness",null);l(this,"onLocationClick");l(this,"usedCachedScores",!1);this.init()}async init(){this.showLoading();try{let s=null;this.unsubscribeFreshness=u.subscribe(()=>{s&&clearTimeout(s),s=setTimeout(()=>{this.refresh()},500)}),await this.refresh(),this.startAutoRefresh()}catch(s){console.error("[StrategicRiskPanel] Init error:",s),this.showError(e("common.failedRiskOverview"))}}startAutoRefresh(){this.refreshInterval=setInterval(()=>this.refresh(),300*1e3)}async refresh(){this.freshnessSummary=u.getSummary(),this.convergenceAlerts=$(),this.overview=b(this.convergenceAlerts),this.alerts=R(24);const{inLearning:s}=k();if(this.usedCachedScores=!1,s){const t=await w(this.signal);t&&t.strategicRisk&&(this.usedCachedScores=!0,console.log("[StrategicRiskPanel] Using cached scores from backend"))}!this.freshnessSummary||this.freshnessSummary.activeSources===0?this.setDataBadge("unavailable"):this.usedCachedScores?this.setDataBadge("cached"):this.setDataBadge("live"),this.render()}getScoreColor(s){return s>=70?c("--semantic-critical"):s>=50?c("--semantic-high"):s>=30?c("--semantic-elevated"):c("--semantic-normal")}getScoreLevel(s){return s>=70?e("components.strategicRisk.levels.critical"):s>=50?e("components.strategicRisk.levels.elevated"):s>=30?e("components.strategicRisk.levels.moderate"):e("components.strategicRisk.levels.low")}getTrendEmoji(s){switch(s){case"escalating":return"📈";case"de-escalating":return"📉";default:return"➡️"}}getTrendColor(s){switch(s){case"escalating":return c("--semantic-critical");case"de-escalating":return c("--semantic-normal");default:return c("--text-dim")}}getPriorityColor(s){switch(s){case"critical":return c("--semantic-critical");case"high":return c("--semantic-high");case"medium":return c("--semantic-elevated");case"low":return c("--semantic-normal")}}getPriorityEmoji(s){switch(s){case"critical":return"🔴";case"high":return"🟠";case"medium":return"🟡";case"low":return"🟢"}}getTypeEmoji(s){switch(s){case"convergence":return"🎯";case"cii_spike":return"📊";case"cascade":return"🔗";case"composite":return"⚠️";default:return"📍"}}renderInsufficientData(){const s=u.getAllSources(),t=s.filter(i=>i.requiredForRisk);return`
      <div class="strategic-risk-panel">
        <div class="risk-no-data">
          <div class="risk-no-data-icon">⚠️</div>
          <div class="risk-no-data-title">${e("components.strategicRisk.insufficientData")}</div>
          <div class="risk-no-data-desc">
            ${e("components.strategicRisk.unableToAssess")}<br>${e("components.strategicRisk.enableDataSources")}
          </div>
        </div>

        <div class="risk-section">
          <div class="risk-section-title">${e("components.strategicRisk.requiredDataSources")}</div>
          <div class="risk-sources">
            ${t.map(i=>this.renderSourceRow(i)).join("")}
          </div>
        </div>

        <div class="risk-section">
          <div class="risk-section-title">${e("components.strategicRisk.optionalSources")}</div>
          <div class="risk-sources">
            ${s.filter(i=>!i.requiredForRisk).slice(0,4).map(i=>this.renderSourceRow(i)).join("")}
          </div>
        </div>

        <div class="risk-actions">
          <button class="risk-action-btn risk-action-primary" data-action="enable-core">
            ${e("components.strategicRisk.enableCoreFeeds")}
          </button>
        </div>

        <div class="risk-footer">
          <span class="risk-updated">${e("components.strategicRisk.waitingForData")}</span>
          <button class="risk-refresh-btn">${e("components.strategicRisk.refresh")}</button>
        </div>
      </div>
    `}renderFullData(){if(!this.overview||!this.freshnessSummary)return"";const s=this.overview.compositeScore,t=this.getScoreColor(s),i=this.getScoreLevel(s),o=Math.round(s/100*270),{inLearning:v,remainingMinutes:r,progress:a}=k();return`
      <div class="strategic-risk-panel">
        ${v&&!this.usedCachedScores?`<div class="risk-status-banner risk-status-learning">
          <span class="risk-status-icon">📊</span>
          <span class="risk-status-text">${e("components.strategicRisk.learningMode",{minutes:String(r)})}</span>
          <div class="learning-progress-mini">
            <div class="learning-bar" style="width: ${a}%"></div>
          </div>
        </div>`:""}

        <div class="risk-gauge">
          <div class="risk-score-container">
            <div class="risk-score-ring" style="--score-color: ${t}; --score-deg: ${o}deg;">
              <div class="risk-score-inner">
                <div class="risk-score" style="color: ${t}">${s}</div>
                <div class="risk-level" style="color: ${t}">${i}</div>
              </div>
            </div>
          </div>
          <div class="risk-trend-container">
            <span class="risk-trend-label">${e("components.strategicRisk.trend")}</span>
            <div class="risk-trend" style="color: ${this.getTrendColor(this.overview.trend)}">
              ${this.getTrendEmoji(this.overview.trend)} ${this.overview.trend==="escalating"?e("components.strategicRisk.trends.escalating"):this.overview.trend==="de-escalating"?e("components.strategicRisk.trends.deEscalating"):e("components.strategicRisk.trends.stable")}
            </div>
          </div>
        </div>

        ${this.renderMetrics()}
        ${this.renderTopRisks()}
        ${this.renderRecentAlerts()}

        <div class="risk-footer">
          <span class="risk-updated">${e("components.strategicRisk.updated",{time:this.overview.timestamp.toLocaleTimeString()})}</span>
          <button class="risk-refresh-btn">${e("components.strategicRisk.refresh")}</button>
        </div>
      </div>
    `}renderSourceRow(s){const t=u.getPanelIdForSource(s.id),i=u.getTimeSince(s.id);return`
      <div class="risk-source-row">
        <span class="risk-source-status" style="color: ${S(s.status)}">
          ${y(s.status)}
        </span>
        <span class="risk-source-name">${m(s.name)}</span>
        <span class="risk-source-time">${s.status==="no_data"?e("components.strategicRisk.noData"):i}</span>
        ${t&&(s.status==="no_data"||s.status==="disabled")?`
          <button class="risk-source-enable" data-panel="${t}">${e("components.strategicRisk.enable")}</button>
        `:""}
      </div>
    `}renderMetrics(){if(!this.overview)return"";const s=C();return`
      <div class="risk-metrics">
        <div class="risk-metric">
          <span class="risk-metric-value">${this.overview.convergenceAlerts}</span>
          <span class="risk-metric-label">${e("components.strategicRisk.convergenceMetric")}</span>
        </div>
        <div class="risk-metric">
          <span class="risk-metric-value">${this.overview.avgCIIDeviation.toFixed(1)}</span>
          <span class="risk-metric-label">${e("components.strategicRisk.ciiDeviation")}</span>
        </div>
        <div class="risk-metric">
          <span class="risk-metric-value">${this.overview.infrastructureIncidents}</span>
          <span class="risk-metric-label">${e("components.strategicRisk.infraEvents")}</span>
        </div>
        <div class="risk-metric">
          <span class="risk-metric-value">${s.critical+s.high}</span>
          <span class="risk-metric-label">${e("components.strategicRisk.highAlerts")}</span>
        </div>
      </div>
    `}renderTopRisks(){if(!this.overview||this.overview.topRisks.length===0)return`<div class="risk-empty">${e("components.strategicRisk.noRisks")}</div>`;const s=this.overview.topConvergenceZones[0];return`
      <div class="risk-section">
        <div class="risk-section-title">${e("components.strategicRisk.topRisks")}</div>
        <div class="risk-list">
          ${this.overview.topRisks.map((t,i)=>i===0&&t.startsWith("Convergence:")&&s?`
                <div class="risk-item risk-item-clickable" data-lat="${s.lat}" data-lon="${s.lon}">
                  <span class="risk-rank">${i+1}.</span>
                  <span class="risk-text">${m(t)}</span>
                  <span class="risk-location-icon">↗</span>
                </div>
              `:`
              <div class="risk-item">
                <span class="risk-rank">${i+1}.</span>
                <span class="risk-text">${m(t)}</span>
              </div>
            `).join("")}
        </div>
      </div>
    `}renderRecentAlerts(){if(this.alerts.length===0)return"";const s=this.alerts.slice(0,5);return`
      <div class="risk-section">
        <div class="risk-section-title">${e("components.strategicRisk.recentAlerts",{count:String(this.alerts.length)})}</div>
        <div class="risk-alerts">
          ${s.map(t=>{const i=t.location&&t.location.lat&&t.location.lon,o=i?"risk-alert-clickable":"",v=i?`data-lat="${t.location.lat}" data-lon="${t.location.lon}"`:"";return`
              <div class="risk-alert ${o}" style="border-left: 3px solid ${this.getPriorityColor(t.priority)}" ${v}>
                <div class="risk-alert-header">
                  <span class="risk-alert-type">${this.getTypeEmoji(t.type)}</span>
                  <span class="risk-alert-priority">${this.getPriorityEmoji(t.priority)}</span>
                  <span class="risk-alert-title">${m(t.title)}</span>
                  ${i?'<span class="risk-location-icon">↗</span>':""}
                </div>
                <div class="risk-alert-summary">${m(t.summary)}</div>
                <div class="risk-alert-time">${this.formatTime(t.timestamp)}</div>
              </div>
            `}).join("")}
        </div>
      </div>
    `}formatTime(s){const i=new Date().getTime()-s.getTime(),o=Math.floor(i/6e4),v=Math.floor(o/60);return o<1?e("components.strategicRisk.time.justNow"):o<60?e("components.strategicRisk.time.minutesAgo",{count:String(o)}):v<24?e("components.strategicRisk.time.hoursAgo",{count:String(v)}):s.toLocaleDateString()}render(){if(this.freshnessSummary=u.getSummary(),!this.overview){this.showLoading();return}let s;const t=performance.now();this.freshnessSummary.overallStatus==="insufficient"&&t>6e4?s=this.renderInsufficientData():s=this.renderFullData(),this.content.innerHTML=s,this.attachEventListeners()}attachEventListeners(){const s=this.content.querySelector(".risk-refresh-btn");s&&s.addEventListener("click",()=>this.refresh()),this.content.querySelectorAll(".risk-source-enable").forEach(r=>{r.addEventListener("click",a=>{const n=a.target.dataset.panel;n&&this.emitEnablePanel(n)})}),this.content.querySelectorAll(".risk-action-btn").forEach(r=>{r.addEventListener("click",a=>{const n=a.target.dataset.action;n==="enable-core"?this.emitEnablePanels(["protests","intel","live-news"]):n==="enable-all"&&this.emitEnablePanels(["protests","intel","live-news","military","shipping"])})}),this.content.querySelectorAll(".risk-item-clickable").forEach(r=>{r.addEventListener("click",()=>{const a=parseFloat(r.dataset.lat||"0"),n=parseFloat(r.dataset.lon||"0");this.onLocationClick&&!isNaN(a)&&!isNaN(n)&&this.onLocationClick(a,n)})}),this.content.querySelectorAll(".risk-alert-clickable").forEach(r=>{r.addEventListener("click",()=>{const a=parseFloat(r.dataset.lat||"0"),n=parseFloat(r.dataset.lon||"0");this.onLocationClick&&!isNaN(a)&&!isNaN(n)&&this.onLocationClick(a,n)})})}emitEnablePanel(s){window.dispatchEvent(new CustomEvent("enable-panel",{detail:{panelId:s}}))}emitEnablePanels(s){s.forEach(t=>this.emitEnablePanel(t))}destroy(){this.refreshInterval&&clearInterval(this.refreshInterval),this.unsubscribeFreshness&&this.unsubscribeFreshness(),super.destroy()}getOverview(){return this.overview}getAlerts(){return this.alerts}setLocationClickHandler(s){this.onLocationClick=s}}export{M as StrategicRiskPanel};
