var d=Object.defineProperty;var h=(i,n,s)=>n in i?d(i,n,{enumerable:!0,configurable:!0,writable:!0,value:s}):i[n]=s;var a=(i,n,s)=>h(i,typeof n!="symbol"?n+"":n,s);import{P as l,e as o}from"./sanitize-D3oJtyS4.js";import{a as e}from"./pipelines-data-BE8dV597.js";import{C as p}from"./main-BS9nt2LU.js";import"./deck-stack-BRjwSfZ4.js";import"./i18n-VWbTNjcU.js";import"./maplibre-BoH-_h6q.js";import"./LiveNewsPanel-OJY2LGeN.js";import"./d3-BN6y_yP-.js";import"./topojson-BwRznoQ3.js";const m={USA:"🇺🇸",CHN:"🇨🇳",JPN:"🇯🇵",DEU:"🇩🇪",KOR:"🇰🇷",GBR:"🇬🇧",IND:"🇮🇳",ISR:"🇮🇱",SGP:"🇸🇬",TWN:"🇹🇼",FRA:"🇫🇷",CAN:"🇨🇦",SWE:"🇸🇪",NLD:"🇳🇱",CHE:"🇨🇭",FIN:"🇫🇮",IRL:"🇮🇪",AUS:"🇦🇺",BRA:"🇧🇷",IDN:"🇮🇩",ESP:"🇪🇸",ITA:"🇮🇹",MEX:"🇲🇽",RUS:"🇷🇺",TUR:"🇹🇷",SAU:"🇸🇦",ARE:"🇦🇪",POL:"🇵🇱",THA:"🇹🇭",MYS:"🇲🇾",VNM:"🇻🇳",PHL:"🇵🇭",NZL:"🇳🇿",AUT:"🇦🇹",BEL:"🇧🇪",DNK:"🇩🇰",NOR:"🇳🇴",PRT:"🇵🇹",CZE:"🇨🇿",ZAF:"🇿🇦",NGA:"🇳🇬",KEN:"🇰🇪",EGY:"🇪🇬",ARG:"🇦🇷",CHL:"🇨🇱",COL:"🇨🇴",PAK:"🇵🇰",BGD:"🇧🇩",UKR:"🇺🇦",ROU:"🇷🇴",EST:"🇪🇪",LVA:"🇱🇻",LTU:"🇱🇹",HUN:"🇭🇺",GRC:"🇬🇷",QAT:"🇶🇦",BHR:"🇧🇭",KWT:"🇰🇼",OMN:"🇴🇲",JOR:"🇯🇴"};class N extends l{constructor(){super({id:"tech-readiness",title:e("panels.techReadiness"),showCount:!0,infoTooltip:e("components.techReadiness.infoTooltip")});a(this,"rankings",[]);a(this,"loading",!1);a(this,"lastFetch",0);a(this,"REFRESH_INTERVAL",360*60*1e3)}async refresh(){if(!this.loading&&!(Date.now()-this.lastFetch<this.REFRESH_INTERVAL&&this.rankings.length>0)){this.loading=!0,this.showFetchingState();try{this.rankings=await p(),this.lastFetch=Date.now(),this.setCount(this.rankings.length),this.render()}catch(s){console.error("[TechReadinessPanel] Error fetching data:",s),this.showError(e("common.failedTechReadiness"))}finally{this.loading=!1}}}showFetchingState(){this.setContent(`
      <div class="tech-fetch-progress">
        <div class="tech-fetch-icon">
          <div class="tech-globe-ring"></div>
          <span class="tech-globe">🌐</span>
        </div>
        <div class="tech-fetch-title">${e("components.techReadiness.fetchingData")}</div>
        <div class="tech-fetch-indicators">
          <div class="tech-indicator-item" style="animation-delay: 0s">
            <span class="tech-indicator-icon">🌐</span>
            <span class="tech-indicator-name">${e("components.techReadiness.internetUsersIndicator")}</span>
            <span class="tech-indicator-status"></span>
          </div>
          <div class="tech-indicator-item" style="animation-delay: 0.2s">
            <span class="tech-indicator-icon">📱</span>
            <span class="tech-indicator-name">${e("components.techReadiness.mobileSubscriptionsIndicator")}</span>
            <span class="tech-indicator-status"></span>
          </div>
          <div class="tech-indicator-item" style="animation-delay: 0.4s">
            <span class="tech-indicator-icon">📡</span>
            <span class="tech-indicator-name">${e("components.techReadiness.broadbandAccess")}</span>
            <span class="tech-indicator-status"></span>
          </div>
          <div class="tech-indicator-item" style="animation-delay: 0.6s">
            <span class="tech-indicator-icon">🔬</span>
            <span class="tech-indicator-name">${e("components.techReadiness.rdExpenditure")}</span>
            <span class="tech-indicator-status"></span>
          </div>
        </div>
        <div class="tech-fetch-note">${e("components.techReadiness.analyzingCountries")}</div>
      </div>
    `)}getFlag(s){return m[s]||"🌐"}getScoreClass(s){return s>=70?"high":s>=40?"medium":"low"}formatComponent(s){return s===null?"—":Math.round(s).toString()}render(){if(this.rankings.length===0){this.showError(e("common.noDataAvailable"));return}const r=`
      <div class="tech-readiness-list">
        ${this.rankings.slice(0,25).map(t=>{const c=this.getScoreClass(t.score);return`
            <div class="readiness-item ${c}" data-country="${o(t.country)}">
              <div class="readiness-rank">#${t.rank}</div>
              <div class="readiness-flag">${this.getFlag(t.country)}</div>
              <div class="readiness-info">
                <div class="readiness-name">${o(t.countryName)}</div>
                <div class="readiness-components">
                  <span title="${e("components.techReadiness.internetUsers")}">🌐${this.formatComponent(t.components.internet)}</span>
                  <span title="${e("components.techReadiness.mobileSubscriptions")}">📱${this.formatComponent(t.components.mobile)}</span>
                  <span title="${e("components.techReadiness.rdSpending")}">🔬${this.formatComponent(t.components.rdSpend)}</span>
                </div>
              </div>
              <div class="readiness-score ${c}">${t.score}</div>
            </div>
          `}).join("")}
      </div>
      <div class="readiness-footer">
        <span class="readiness-source">${e("components.techReadiness.source")}</span>
        <span class="readiness-updated">${e("components.techReadiness.updated",{date:new Date(this.lastFetch).toLocaleDateString()})}</span>
      </div>
    `;this.setContent(r)}}export{N as TechReadinessPanel};
