declare const process: { env: Record<string, string | undefined> };

import type {
  ServerContext,
  GetAircraftDetailsBatchRequest,
  GetAircraftDetailsBatchResponse,
  AircraftDetails,
} from '../../../../src/generated/server/worldmonitor/military/v1/service_server';

import { mapHexdbDetails } from './_shared';
import { CHROME_UA } from '../../../_shared/constants';
import { getCachedJsonBatch, cachedFetchJson } from '../../../_shared/redis';

interface CachedAircraftDetails {
  details: AircraftDetails | null;
  configured: boolean;
}

export async function getAircraftDetailsBatch(
  _ctx: ServerContext,
  req: GetAircraftDetailsBatchRequest,
): Promise<GetAircraftDetailsBatchResponse> {
  const normalized = req.icao24s
    .map((id) => id.trim().toLowerCase())
    .filter((id) => id.length > 0);
  const uniqueSorted = Array.from(new Set(normalized)).sort();
  const limitedList = uniqueSorted.slice(0, 10);

  // Redis shared cache — batch GET all keys in a single pipeline round-trip
  const SINGLE_KEY = 'military:aircraft:v1:hexdb';
  const SINGLE_TTL = 24 * 60 * 60;
  const results: Record<string, AircraftDetails> = {};
  const toFetch: string[] = [];

  const cacheKeys = limitedList.map((icao24) => `${SINGLE_KEY}:${icao24}`);
  const cachedMap = await getCachedJsonBatch(cacheKeys);

  for (let i = 0; i < limitedList.length; i++) {
    const icao24 = limitedList[i]!;
    const cached = cachedMap.get(cacheKeys[i]!);
    if (cached && typeof cached === 'object' && 'details' in cached) {
      const details = (cached as { details?: AircraftDetails | null }).details;
      if (details) {
        results[icao24] = details;
      }
      // details === null means cached negative lookup; skip refetch.
    } else {
      toFetch.push(icao24);
    }
  }

  const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

  for (let i = 0; i < toFetch.length; i++) {
    const icao24 = toFetch[i]!;
    const cacheResult = await cachedFetchJson<CachedAircraftDetails | null>(
      `${SINGLE_KEY}:${icao24}`,
      SINGLE_TTL,
      async () => {
        try {
          const resp = await fetch(`https://hexdb.io/api/v1/aircraft/${icao24}`, {
            headers: { Accept: 'application/json', 'User-Agent': CHROME_UA },
            signal: AbortSignal.timeout(10_000),
          });
          if (resp.status === 404) {
            return { details: null, configured: true };
          }
          if (resp.ok) {
            const text = await resp.text();
            try {
              const data = JSON.parse(text) as Record<string, unknown>;
              if (data.status === '404' || data.error === 'Aircraft not found.') {
                return { details: null, configured: true };
              }
              const details = mapHexdbDetails(icao24, data);
              return { details, configured: true };
            } catch {
              return null;
            }
          }
        } catch { /* skip failed lookups */ }
        return null;
      },
    );
    if (cacheResult?.details) results[icao24] = cacheResult.details;
    if (i < toFetch.length - 1) await delay(100);
  }

  return {
    results,
    fetched: Object.keys(results).length,
    requested: limitedList.length,
    configured: true,
  };
}
